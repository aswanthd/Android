var camera, scene, renderer;
var controls;
var width = 600;
var heigt = 600;
var FrontElement = function(property,x, y, z, ry,color,image) {
    var div = document.createElement('div');
    div.style.width = property.width;//'480px'
    div.style.height = property.height;//'180px';
    div.style.backgroundColor = color;
    var img = document.createElement('img');   
    div.className = "bgcover"; 
    if(image) { img.src=image; }
    img.className="image";
    div.appendChild(img);   

    var object = new THREE.CSS3DObject(div);
    object.position.set(x, y, z);        
    object.rotation.y = ry; 
    return object;                     
};

var SideElement = function(property,x, y, z, ry,color,images) {
    var div = document.createElement('div');
    div.style.width = property.width;//'480px'
    div.style.height = property.height;//'180px';
    div.style.backgroundColor = color;
    div.className = "bgcover";
    if(images) {
     images.forEach(function(image){
          var img = document.createElement('img');    
          if(image) { img.src = image.source; }
          img.className= image.className;
          div.appendChild(img);   
     });    
    }
    var object = new THREE.CSS3DObject(div);
    object.position.set(x, y, z);        
    object.rotation.y = ry; 
    return object;                     
};

var OtherElement = function(dimension,x, y, z, ry,color,images) {
    var div = document.createElement('div');
    div.style.width = dimension.width;//'480px'
    div.style.height = dimension.height;//'180px';
     div.className = "bgcover";
    div.style.backgroundColor = color;
    if(images){
     images.forEach(function(image){
          var img = document.createElement('img');    
          if(image) { img.src = image.source; }
          img.className= image.className;
          div.appendChild(img);   
    });    
    }
    var object = new THREE.CSS3DObject(div);
    object.position.set(x, y, z);        
    object.rotation.x = ry;     
    return object;
};


init();
animate();

function init() {

    var container = document.getElementById('container');

    camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 1, 5000);
    camera.position.set(500, 350, 750);

    scene = new THREE.Scene();

    renderer = new THREE.CSS3DRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.top = 0;
    container.appendChild(renderer.domElement);

    var group = new THREE.Group();
    var frontBackdimension = { width:'240px', height:'180px' };
    var sidedimension = { width:'480px', height:'180px' };
    var dimension = { width:'240px', height:'480px' };
    var colorCube = '#f5f5f5';
    var colorSides = '#ffffff';
    var rightImages = [{ source:'css/images/sidewall1_01.png',className:'quater'},                        
                        { source:'css/images/sidewall1_02.png',className:'quater'},
                        { source:'css/images/sidewall1_03.png',className:'quater'},
                        { source:'css/images/sidewall1_04.png',className:'quater'}];
     var leftImages = [{ source:'css/images/sidewall2_01.png',className:'quater'},                        
                        { source:'css/images/sidewall2_02.png',className:'quater'},
                        { source:'css/images/sidewall2_03.png',className:'quater'},
                        { source:'css/images/sidewall2_04.png',className:'quater'}];

    //Red Front    
    group.add(new FrontElement(frontBackdimension,0, 0, 240, 0,colorCube));
    group.add(new FrontElement(frontBackdimension,0, 0, 300, 0,'#ffffff',"css/images/frontpanel.png"));    
    
    //Yellow Side
    group.add(new SideElement(sidedimension,120, 0, 0, Math.PI / 2,colorCube));
    group.add(new SideElement(sidedimension,180, 0, 0, Math.PI / 2,colorSides,rightImages));

    //Green Side
    group.add(new SideElement(sidedimension,-120, 0, 0, -Math.PI / 2, colorCube));
    group.add(new SideElement(sidedimension,-180, 0, 0, -Math.PI / 2, colorSides,leftImages));

    //Blue Back
    group.add(new FrontElement(frontBackdimension,0, 0, -240, Math.PI,colorCube));
    group.add(new FrontElement(frontBackdimension,0, 0, -300, Math.PI,'#ffffff',"css/images/backpanel.png"));

    //purple Top
    group.add(new OtherElement(dimension,0, 90, 0, -Math.PI / 2,colorCube));
    group.add(new OtherElement(dimension,0, 150, 0, -Math.PI / 2,colorSides,leftImages));

    //Rose Bottom
    group.add(new OtherElement(dimension,0, -90, 0, -Math.PI / 2,colorCube));
    group.add(new OtherElement(dimension,0, -150, 0, -Math.PI / 2,colorSides,leftImages));

    scene.add(group);

    controls = new THREE.TrackballControls(camera);
    controls.rotateSpeed = 4;

    window.addEventListener('resize', onWindowResize, false);
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

function animate() {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
}


		