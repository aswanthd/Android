﻿depot['subdivision'] = {
    init: function (arg) {
        var searchContainer = document.getElementById('searcharea');
        if (searchContainer.innerHTML !== "") {
            searchContainer.innerHTML = "";
        }
        this.url = arg.url;
        this.constant = arg.constant;
        this.msg = arg.msg;
        this.omodel = this.updateModel(arg.model);
        depot.common.dateValidation();
        this.bindModel();
    },
    id: {
        grid: "#SubDivisionGrid",
    },
    page: '#SubDivisionHead',
    url: {},
    constant: {},
    msg: {},
    omodel: {},
    customSource: function (obj) {
        return new kendo.data.DataSource({
            pageSize: 10,
            page: 1,
            total: 0,
            serverPaging: true,
            serverFiltering: false,
            serverGrouping: true,
            serverAggregates: true,
            filter: [],
            schema: {
                data: "Data",
                total: "Total",
            },
            transport: {
                read: {
                    url: obj.url,
                    type: "POST",
                    beforeSend: Ajax.AddCsrfToken,
                    dataType: "json",

                },
                parameterMap: function (options, operation) {
                    if (operation == "read" && options) {
                        var model = { countrySubDivision: depot.subdivision.getparams() };
                        model.page = options.page;
                        model.pageSize = options.pageSize;
                        return JSON.parse(JSON.stringify(model));
                    }
                }
            },
            error: function (request) {
                depot.common.clienterror(request, "Country Subdivisions");
            }
        });
    },
    source: function (obj) {
        return new kendo.data.DataSource({
            pageSize: obj.pageSize,
            pageable: false,
            serverPaging: false,
            serverFiltering: false,
            transport: {
                read: {
                    url: obj.url,
                    type: "GET",
                    dataType: "json",
                    data: obj.data || function () {
                        return {
                            search: ''
                        };
                    },
                },
            },
            schema: {
                total: "Total", // total is returned in the "total" field of the response ,
                data: "Data"
            },
            error: function (request) {
                depot.common.clienterror(request, "Country Subdivisions");
            }
        });
    },
    gridClick: function (e) {
        var searchContainer = document.getElementById('searcharea');
        var grid = $(depot.subdivision.id.grid).data("kendoGrid");
        var selectedItem = grid.dataItem(grid.select());
        searchContainer.appendChild(document.getElementById('SubDivisionHead'));
        depot.subdivision.getDamagelocationDetailById(selectedItem.Id);
    },
    getDamagelocationDetailById: function (id) {
        depot.loader.navigate(depot.subdivision.url.edit + "?id=" + id);
    },
    updateModel: function (model) {
        var currentItem = this;
        model.gridClick = currentItem.gridClick;
        model.applyFilter = currentItem.ApplyFilter;
        model.countrylist = currentItem.source({ url: currentItem.url.countryurl });
        model.addNew = currentItem.createNew;
        model.subdivision = currentItem.source({ url: currentItem.url.subdivisionsearchs, data: { searchText: 'IncludeInActive' } });
        model.subdivisiontypes = currentItem.source({ url: currentItem.url.searchGeneralCodes + '?reference=' + currentItem.constant.SUBDIVITIONTYPE });
        model.searchstatus = currentItem.source({ url: currentItem.url.searchGeneralCodes + '?reference=' + currentItem.constant.STATUSCODE });
        model.subdivisionlist = currentItem.customSource({
            url: currentItem.url.subdivisionlists,
            data: currentItem.getparams()
        });
        model.clearFilter = currentItem.clearFilter;
        model.ShowFilter = currentItem.ShowFilter;
        return depot.observable(model);
    },
    getparams: function () {
        return {
            Code: depot.subdivision.omodel.Code,
            Name: depot.subdivision.omodel.Name,
            ValidFrom: depot.common.toDateString(depot.subdivision.omodel.ValidFrom),
            ValidTo: depot.common.toDateString(depot.subdivision.omodel.ValidTo),
            Status: depot.subdivision.omodel.Status,
            CountryId: depot.subdivision.omodel.CountryId,
            SubDivisionType: depot.subdivision.omodel.SubDivisionType
        };
    },
    ApplyFilter: function (e) {
        if (e) {
            e.preventDefault();
        }
        var grid = $(depot.subdivision.id.grid).data("kendoGrid");
        grid.dataSource.page(1);
    },
    createNew: function (e) {
        e.preventDefault();
        depot.loader.navigate(depot.subdivision.url.addsubdivision);
    },
    clearFilter: function () {
        var grid = $(depot.subdivision.id.grid).data("kendoGrid");
        depot.subdivision.omodel.set("Code", "");
        depot.subdivision.omodel.set("Name", "");
        depot.subdivision.omodel.set("ValidFrom", "");
        depot.subdivision.omodel.set("ValidTo", "");
        depot.subdivision.omodel.set("Status", "");
        depot.subdivision.omodel.set("SubDivisionType", "");
        depot.subdivision.omodel.set("CountryId", "");
        grid.dataSource.page(1);
        e.preventDefault();
    },
    ShowFilter: function (e) {
        var text = $.trim(e.currentTarget.innerText);
        if (text === depot.common.constants.btnShowFilter) {
            e.currentTarget.innerHTML = "<i class='fa fa-angle-double-up' aria-hidden='true'></i>&nbsp;" + depot.common.constants.btnHideFilter;
        } else {
            e.currentTarget.innerHTML = "<i class='fa fa-angle-double-down' aria-hidden='true'></i>&nbsp;" + depot.common.constants.btnShowFilter;
        }
    },
    bindModel: function () {
        depot.bind(this.page, this.omodel);
    },
};