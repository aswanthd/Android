﻿depot['subdivisioncreate'] = {
    init: function (arg) {
        this.url = arg.url;
        this.constant = arg.constant;
        this.msg = arg.msg;
        this.messages = JSON.parse(arg.resources);
        this.omodel = this.updateModel(arg.model);
        this.loadValidation();
        this.bindModel();
        depot.common.dateValidation();
    },
    page: '#divCreatesubdivision',
    url: {},
    constant: {},
    msg: {},
    messages: {},
    omodel: {},
    source: function (obj) {
        return new kendo.data.DataSource({
            pageSize: obj.pageSize ,
            pageable: false,
            serverPaging: false,
            serverFiltering: false,
            transport: {
                read: {
                    url: obj.url,
                    type: "GET",
                    dataType: "json",
                    data: obj.data || function () {
                        return {
                            search: ''
                        };
                    },
                },
            },
            schema: {
                total: "Total",
                data: "Data"
            },
            error: function (request) {
                depot.common.clienterror(request, depot.subdivisioncreate.messages.LBL_CTRYSUBDIVMESSAGEHEADER);
            }
        });
    },
    updateModel: function (model) {
        var currentItem = this;
        model.lov = {};
        model = depot.common.DecodeJsonObject(model);
        model.confirmSave = currentItem.confirmSave;
        model.cancel = currentItem.cancel;
        model.lov.countrylist = currentItem.source({ url: currentItem.url.countryurl });
        model.searchStatus = currentItem.source({ url: currentItem.url.searchGeneralCodes + '?reference=' + currentItem.constant.STATUSCODE });
        model.lov.subDivisionType = currentItem.source({ url: currentItem.url.searchGeneralCodes + '?reference=' + currentItem.constant.SUBDIVITIONTYPE });
        model.delsubdivision = currentItem.deletesubdivisions;
        model.startChange = currentItem.startChange;
        model.endChange = currentItem.endChange;
        return depot.observable(model);
    },
    confirmSave: function (e) {
        e.preventDefault();
        if (depot.subdivisioncreate.omodel.Status.Code == depot.common.constants.deletestatus) {
            depot.common.YesNoShowMessage(depot.common.constants.saveconfirmation, depot.subdivisioncreate.messages.LBL_CTRYSUBDIVMESSAGEHEADER, [{
                text: depot.common.constants.btnactivate, action: "depot.subdivisioncreate.save()"
            }], [{
                text: depot.common.constants.btnCancel, action: "depot.common.close()"
            }])
        }
        else {
            depot.subdivisioncreate.save();
        }
    },
    save: function (e) {
        var outCome = {};
        depot.subdivisioncreate.omodel.lov = undefined;        
        depot.subdivisioncreate.omodel.Status.set("Code", depot.common.constants.savestatus);
        outCome = depot.validation.IsValid('Edit');
        if (outCome.isValid) {
            cmodel = { countrySubDivision: JSON.parse(JSON.stringify(depot.subdivisioncreate.omodel)) };
            Ajax.Request({
                url: depot.subdivisioncreate.url.saveurl,
                type: "POST",
                data: cmodel,
                cache: false,
                success: function (data) {
                    if (data.success) {
                        depot.common.ShowMessage(data.message, depot.subdivisioncreate.messages.LBL_CTRYSUBDIVMESSAGEHEADER, [{ text: depot.common.constants.btnOk, action: "depot.subdivisioncreate.confirmcancel()" }]);
                    }
                    else {
                        depot.common.ShowMessage(data.message, depot.subdivisioncreate.messages.LBL_CTRYSUBDIVMESSAGEHEADER, [{
                            text: depot.common.constants.btnOk, action: "depot.common.ClosePopup()"
                        }])
                    }
                },
                error: function (data) {
                    depot.common.ShowMessage(depot.common.constants.msgErrorOccured, depot.subdivisioncreate.messages.LBL_CTRYSUBDIVMESSAGEHEADER)
                }
            });
        }
        else
        {
            depot.common.ShowMessage(outCome.message, depot.subdivisioncreate.messages.LBL_CTRYSUBDIVMESSAGEHEADER);
        }
    },
    deletesubdivisions: function (e) {
        depot.common.YesNoShowMessage(depot.common.constants.deleteconfirmation, depot.subdivisioncreate.messages.LBL_CTRYSUBDIVMESSAGEHEADER, [{
            text: depot.common.constants.btndeactivate, action: "depot.subdivisioncreate.confirmdeletesubdivisions()"
        }], [{
            text: depot.common.constants.btnNo, action: "depot.common.ClosePopup()"
        }])
    },
    confirmdeletesubdivisions: function (e) {
        cmodel = JSON.parse(JSON.stringify(depot.subdivisioncreate.omodel));
        Ajax.Request({
            url: depot.subdivisioncreate.url.deletesubdivision,
            type: "GET",
            data: {
                countrySubDivisionId: cmodel.Id,
                countryId: cmodel.CountryId
            },
            cache: false,
            success: function (data) {
                if (data.success) {
                    depot.common.ShowMessage(data.message, depot.subdivisioncreate.messages.LBL_CTRYSUBDIVMESSAGEHEADER, [{ text: depot.common.constants.btnOk, action: "depot.subdivisioncreate.confirmcancel()" }]);
                }
                else {
                    depot.common.ShowMessage(data.message, depot.subdivisioncreate.messages.LBL_CTRYSUBDIVMESSAGEHEADER)
                }
            },
            error: function (data) {
                depot.common.ShowMessage(depot.common.constants.msgErrorOccured, depot.subdivisioncreate.messages.LBL_CTRYSUBDIVMESSAGEHEADER)
            }
        });
    },
    cancel: function () {
        depot.common.YesNoShowMessage(depot.common.constants.cancelconfirmation, depot.subdivisioncreate.messages.LBL_CTRYSUBDIVMESSAGEHEADER, [{
            text: depot.common.constants.btnYes, action: "depot.subdivisioncreate.confirmcancel()"
        }], [{
            text: depot.common.constants.btnNo, action: "depot.common.ClosePopup()"
        }])
    },
    getLockKey: function () {
        return 'countrysubdivision_' + depot.subdivisioncreate.omodel.Id;
    },
    confirmcancel: function () {
        var key = "";
        var id = parseInt(depot.subdivisioncreate.omodel.Id);
        if (id > 0) {
            key = depot.subdivisioncreate.getLockKey();
            StateManager.ReleaseRecord(key, function () {
                var contentContainer = document.getElementById('contentarea');
                var searchContainer = document.getElementById('searcharea');
                if (searchContainer.innerHTML !== "") {
                    contentContainer.innerHTML = "";
                    contentContainer.appendChild(document.getElementById('SubDivisionHead'));
                    depot.subdivision.ApplyFilter();
                }
                else {
                    depot.loader.navigate(depot.subdivisioncreate.url.cancels);
                }
            }, []);
        }
        else {
            depot.loader.navigate(depot.subdivisioncreate.url.cancels);
        }
        depot.common.ClosePopup();
    },
    loadValidation: function () {
        var VH = depot.validation;
        var category = depot.validation.Category.Add('Edit', 'divCreatesubdivision', 'DSM00240', 24);
        VH.Load({ category: 'Edit' });
    },
    bindModel: function () {
        depot.bind(this.page, this.omodel);
    },
    startChange: function () {
        var start = $("#ValidFrom").kendoDatePicker().data("kendoDatePicker");
        var end = $("#ValidTo").kendoDatePicker().data("kendoDatePicker");
        var startDate = start.value();
        var endDate = end.value();
        if (startDate) {
            startDate = new Date(startDate);
            startDate.setDate(startDate.getDate() + 1);
            end.min(startDate);
        } else if (endDate) {
            start.max(new Date(endDate));
        } else {
            endDate = depot.common.getCurrentDateTime();
            start.max(endDate);
            end.min(endDate);
        }
    },
    endChange: function () {
        var start = $("#ValidFrom").kendoDatePicker().data("kendoDatePicker");
        var end = $("#ValidTo").kendoDatePicker().data("kendoDatePicker");
        var startDate = start.value();
        var endDate = end.value();

        if (endDate) {
            endDate = new Date(endDate);
            endDate.setDate(endDate.getDate() - 1);
            start.max(endDate);
        } else if (startDate) {
            end.min(new Date(startDate));
        } else {
            endDate = depot.common.getCurrentDateTime();
            start.max(endDate);
            end.min(endDate);
        }
    },
}