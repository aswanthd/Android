﻿depot['querycountrysubdivision'] = {
    init: function (arg) {
        this.url = arg.url;
        this.constant = arg.constant;
        this.msg = arg.msg;
        this.viewModel = this.updateModel(arg.model);
        var key = 'countrysubdivision_' + this.viewModel.Id;
        StateManager.ReadRecord(key);
        this.bindModel();
    },
    page: '#diveditsubdivision',
    url: {},
    constant: {},
    msg: {},
    viewModel: {},
    updateModel: function (model) {
    	var self = this;
          model.edit = self.edit;
		  model.cancel = self.confirmcancel;
    	return depot.observable(model);
    },
    source: function (obj) {
        return new kendo.data.DataSource({
            pageSize: obj.pageSize ,
            pageable: true,
            serverPaging: true,
            serverFiltering: true,
            transport: {
                read: {
                    url: obj.url,
                    type: "GET",
                    dataType: "json",
                    data: obj.data || function () {
                        return {
                            search: ''
                        };
                    },
                },
            },
            schema: {
                total: "Total",
                data: "Data"
            },
            error: function (request) {
                depot.common.clienterror(request, "Country Subdivisions");
            }
        });
    },
    getLockKey:function(){
        return 'countrysubdivision_' + depot.querycountrysubdivision.viewModel.Id;
    },
    edit: function (e) {
        var key = depot.querycountrysubdivision.getLockKey();
        StateManager.LockRecord(key, function () {
            depot.loader.navigate(depot.querycountrysubdivision.url.editurl + "?id=" + depot.querycountrysubdivision.viewModel.Id);
        }, []);
    },
    confirmcancel: function () {
        var contentContainer = document.getElementById('contentarea');
        var searchContainer = document.getElementById('searcharea');
        if (searchContainer.innerHTML !== "") {
            contentContainer.innerHTML = "";
            contentContainer.appendChild(document.getElementById('SubDivisionHead'));
        }
        else {
            depot.loader.navigate(depot.querycountrysubdivision.url.cancelurl);
        }
    },
    bindModel: function () {
        depot.bind(this.page, this.viewModel);
    },
};