﻿
var login = function () {
    return {
        element: {
            Mode: '#Mode'
        },
        setmode: function (t) {
            $(this.element.Mode).val(t);
        },
        filter: {
            init: function (obj) {
                this.Url = obj.Url;
                this.setModel(JSON.parse(obj.model));
                if (login.filter.omodel.DepotFlag == true)
                {
                    document.getElementById('proceed').disabled = true;
                }
                else
                {
                    document.getElementById('proceed').disabled = false;
                }  
            },
            Url: {},
            page: '#filterpage',
            omodel: {},
            source: function (url) {
                return new kendo.data.DataSource({
                    pageSize: 300,
                    pageable: true,
                    serverPaging: true,
                    serverFiltering: true,
                    transport: {
                        read: {
                            url: url,
                            type: "GET",
                            dataType: "json",
                            data: function () {
                                return { search:'' };
                            },
                        },
                    }
                });
            },           
            updateSource: function (m) {
                debugger;
                var self = this;
                m.seal = ({
                    source: self.source(self.Url.seal),
                });
                m.country = {
                    value: 0,
                    source: self.source(self.Url.country),
                };
                m.cancel = self.cancel;
            },        
            setModel: function (m) {
                this.updateSource(m);
                this.omodel = seal.observable(m);
                seal.bind(this.page, this.omodel);
            },
            Ok: function () {
            },
            proceedClick: function () {

            },
            cancel: function (e) {
                e.preventDefault();
                window.location.href = seal.login.filter.Url.cancelurl;
            }
        }
    }
}();
seal['login'] = login;