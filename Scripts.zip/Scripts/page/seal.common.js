﻿(function (w) {
    w.common = {
        dateformat: "dd/MMM/yyyy",
        datetimeformat: "dd/MMM/yyyy HH:mm",
        yearMonthDateTimeHourMinSecFormat: "yyyy-MM-ddTHH:mm:ss",
        dateFormatyyyyMMdd: "yyyy-MM-dd",
        init: function (o) {
            this.kendoExtension();
            if (o && o.format) {
                w.common.dateformat = o.format.date;
                w.common.datetimeformat = o.format.datetime;
            }
            $('.k-window-titlebar:first-child').dblclick(function (e) { e.preventDefault(); return false; });
        },
        toDateString: function (dt) {
            if (dt !== undefined
                && dt !== null
                && dt !== '') {
                if (dt instanceof Date) {
                    return dt.toDepotFormat();
                }
                return dt;
            }
            return dt;
        },
        clearDate: function (model, property) {
            model.set(property, null);
            model.set(property, seal.common.getCurrentDateTime());
            model.set(property, null);
        },
        setCommonReources: function (o) {
            if (o != undefined) {
                this.commonResources = JSON.parse(o.resources);
                if (this.commonResources != null) {
                    seal.common.constants.cancelconfirmation = this.commonResources.MSG_CONFIRMCANCEL;
                    seal.common.constants.saveconfirmation = this.commonResources.MSG_CONFIRMACTIVATE;
                    seal.common.constants.deleteconfirmation = this.commonResources.MSG_CONFIRMDEACTIVATE;
                    seal.common.constants.deleteforothercases = this.commonResources.MSG_CONFIRMDELETE;
                    seal.common.constants.btnactivate = this.commonResources.BTN_ACTIVATE;
                    seal.common.constants.btndeactivate = this.commonResources.BTN_DEACTIVATE;
                    seal.common.constants.btnDelete = this.commonResources.BTN_DELETE;
                    seal.common.constants.btnOk = this.commonResources.BTN_OK;
                    seal.common.constants.btnConfirm = this.commonResources.BTN_CONFIRM;
                    seal.common.constants.btnCancel = this.commonResources.BTN_CANCEL;
                    seal.common.constants.msgErrorOccured = this.commonResources.MSG_ERROROCCURED;
                    seal.common.constants.btnShowFilter = this.commonResources.BTN_SHOWFILTER;
                    seal.common.constants.btnYes = this.commonResources.BTN_YES;
                    seal.common.constants.btnNo = this.commonResources.BTN_NO;
                    seal.common.constants.btnHideFilter = this.commonResources.BTN_HIDEFILTER;
                    seal.common.constants.txtActive = this.commonResources.TXT_ACTIVE;
                    seal.common.constants.txtInactive = this.commonResources.TXT_INACTIVE;
                    seal.common.constants.txtYes = this.commonResources.TXT_YES;
                    seal.common.constants.txtNo = this.commonResources.TXT_NO;
                }
            }
        },
        commonResources: {},
        constants: {
            savestatus: "A",
            deletestatus: "I",
            cancelconfirmation: "",
            saveconfirmation: "",
            deleteconfirmation: "",
            deleteforothercases: "",
            reverseinvoice: "Do you want to reverse this invoice?",
            cancelinvoice: "Do you want to cancel this invoice?",
            descriptionLenth: 25,
            gridtitledescription: 5,
            btnactivate: "",
            btndeactivate: "",
            btnDelete: "",
            storageTariffEmpty: "Please enter Tariff details",
            btnOk: "",
            btnConfirm: "",
            btnCancel: "",
            msgErrorOccured: "",
            btnShowFilter: "",
            btnYes: "",
            btnNo: "",
            btnHideFilter: "",
            savechildmessage: "Please close the detailed view before proceeding to Save.",
            txtActive: "",
            txtInactive: "",
            txtYes: "",
            txtNo: "",
            yellow: "rgb(254, 203, 0)",
            white: "white",
            defaultdate: "0001-01-01T00:00:00",
            manufacturer: "M",
            flight: "F",
            ship: "S",
            truck: "T",
            barge: "B",
            rail: "R",
            orderplaced: "P",
            draft: "D",
            cancelled: "X",
            dispatched: "O",
            partiallyReceived: "PR",
            confirmed: "C",
            partiallyDispatched: "PD",
            headerAgency: "H",
            subAgency: "S",
        },

        NotificationKeys: {
            Dispatch: "dispatch_",
            // Remaining Keys has to Fill here
        },

        TransportMode: {
            ship: "S",
            barge: "B",
            airway: "F",
            train: "R",
            truck: "T"
        },

        LoginDispacthType: {
            Forwarded: "F",
            DisplayFromOwnStock: "D"
        },

        NotificationType: {
            INFO: "info",
            WARNING: "warning",
            ERROR: "error"
        },

        ScreenInfo: {
            CurrentStockReport: 'C',
            SealRequestReport: 'R',
            SealDispatchReport: 'D',
            SealDiscrepancyReport: 'DS'
        },

        Role:
              {
                  HQ: 'HQ',
                  HeaderAgency: 'H',
                  Agency: 'A',
                  Customer: 'C',
                  Distributor: 'D',
                  Manufacturer: 'M',
                  SubAgency: 'S',
                  Transporter: 'T',
                  Vendor: 'V',
                  AgencySubAgency: "A,S"
              },
        LockKey: {
            PAGE: {
                BUE: "seal_bue_",
                UAM: "seal_uam_",
                RDLINK: "seal_rdlink_",
                UTILIZATION: "seal_utilize_",
                DISCREPANCY: "seal_discrepancy_",
                ORDER: "seal_order_",
                DISPATCH: "seal_dispatch_",
                RECEIPT: "seal_receipt_",
            }
        },

        validationRule:
            {
                GATEENTRY: { ProcessCode: 'DSG00010', Sequence: 1 },
                STACKPLANNING: { ProcessCode: '', Sequence: 1 },
                GATEOUT: { ProcessCode: 'DSG00030', Sequence: 2 },
                GATEEXIT: { ProcessCode: 'DSG00030', Sequence: 1 },
                TRUCKGATEINOUT: { ProcessCode: 'DSG00060', Sequence: 33 },
                JOBCARDCREATION: { ProcessCode: 'DSR00070', Sequence: 75 },
                ASSETGROUPMASTER: { ProcessCode: 'DFA00010', Sequence: 1 },
                ASSETDISPOSAL: { ProcessCode: 'DFA00030', Sequence: 1 },
                ASSETMASTER: { ProcessCode: 'DFA00020', Sequence: 1 },
            },
        MassConvertion:
            {
                ////    let kgtotone = 0.001
                ////        let gtotone = 0.00001;
                ////let poundtotone = 0.00045359237;
                ////let stonestotone = 0.00635029318;
                ////let ouncetotone = 0.00002835;
                ////let uklongtonetotone = 1.01604691;
            },
        checkMinimunRecord: function (data) {
            isValid = true;
            if (data.length > 0) {
                isValid = true;
            }
            return isValid;
        },
        checkMinimunRecordWithRowStatus: function (data) {
            isvalid = false;
            if (data.length == 0) {
                isvalid = false;
            }
            $.each(data, function (index, item) {
                if (item.RecordRowStatus != seal.common.recordRowStatus.Unchanged) {
                    isvalid = true;
                }
            });
            return isvalid;
        },
        recordRowStatus: {
            Unchanged: 0,
            Added: 1,
            Modified: 2,
            Deleted: 3,
        },
        businesspartner:
          {
              AGENT: "A",
              CUSTOMER: "C",
              LINER: "L",
              SURVEYOR: "S",
              TRANSPORTER: "T",
              VENDOR: "V",
              All: "ALL",
              CUSTOMAGENT: "G",
              CARRIERAGENT: "O",
              OTHERCARRIERAGENT: "O",
              CUSTOMSAGENT: "G",
              MSCENTITY: "A,O",
              BUSINESSENTITY: 'ALL',
              HQUser: "M,D,H,A,S",
              HEADERSUBAGENT: "H,S",
          },
        ShowNotification: function (message, title, msgtype) {
            Notifier.UI().show({
                title: title,
                message: message,
            }, msgtype);
        },
        //Model - Page Model with DateFrom Min Max and DateTo Min Max
        //Range - Difference Between DateFrom and  DateTo
        //DateTo Min Max - DatePicker To Min Max
        DateFromChange: function (DateFrom, Model, Range, DateToMin, DateToMax) {
            if (DateFrom != null) {
                let dataRange = new Date(JSON.parse(JSON.stringify(DateFrom)));
                dataRange.setMonth(dataRange.getMonth() + parseInt(Range));
                Model.set(DateToMin, DateFrom);
                Model.set(DateToMax, dataRange);
            }
        },
        //Model - Page Model with DateFrom Min Max and DateTo Min Max
        //Range - Difference Between DateFrom and  DateTo
        //DateFrom Min Max - DatePicker From Min Max
        DateToChange: function (DateTo, Model, Range, DateFromMin, DateFromMax) {
            if (DateTo != null) {
                let dataRange = new Date(JSON.parse(JSON.stringify(DateTo)));
                dataRange.setMonth(dataRange.getMonth() - parseInt(Range));
                Model.set(DateFromMin, dataRange);
                Model.set(DateFromMax, DateTo);
            }
        },
        //Model - Page Model with DateFrom Min Max and DateTo Min Max
        //Range - Difference Between DateFrom and  DateTo(Months)
        //DateFrom,DateTo - DatePicker Value
        //DateFrom Min Max -- DatePicker From Min Max
        //DateTo Min Max -- DatePicker To Min Max
        SetDefaultDate: function (Model, Range, DateFrom, DateTo, DateFromMin, DateFromMax, DateToMin, DateToMax) {
            let FromDate = new Date();
            FromDate.setMonth(FromDate.getMonth() - Range);
            let ToDate = new Date();

            Model.set(DateFromMin, FromDate);
            Model.set(DateFromMax, ToDate);
            Model.set(DateToMin, FromDate);
            Model.set(DateToMax, ToDate);
            Model.set(DateFrom, FromDate);
            Model.set(DateTo, ToDate);

        },
        ShowMessage: function (message, title, btn) {
            if (btn != undefined) {
                var wd = $("#messagebox").data("kendoWindow");
                message = '<p class="clear-message">' + message + '</p>';

                if (btn && btn.length > 0) {
                    message += '<div class="window-footer buttonctr pull-right">';
                    btn.forEach(function (v, i) {
                        message += '<button class="clear-confirm k-button" onclick="' + v.action + '">' + v.text + '</button>';
                    })
                    message += "</div>";
                }
                $("#messagecontent").html(message);
                if (!wd) {
                    wd = $("#messagebox").kendoWindow({
                        width: "600px",
                        title: title,
                        draggable: false,
                        modal: true,
                        position: "relative",
                        top: "50px",
                        actions: [],

                    }).data("kendoWindow");
                }
                else {
                    wd.title(title)
                }
            }
            else {
                var wd = $("#btnmessagebox").data("kendoWindow");
                message = '<p class="clear-message">' + message + '</p>';
                $("#btnmessagecontent").html(message);
                if (!wd) {
                    wd = $("#btnmessagebox").kendoWindow({
                        width: "600px",
                        title: title,
                        draggable: false,
                        modal: true,
                        position: "relative",
                        top: "50px",

                    }).data("kendoWindow");
                }
                else {
                    wd.title(title)
                }
            }

            wd.center().open();
            Ajax.Busy.Overlay.show();
        },
        ShowSuccessMessage: function (message, title, btn) {
            var wd = $("#messagebox").data("kendoWindow");
            message = '<p class="clear-message">' + message + '</p>';
            if (btn && btn.length > 0) {
                message += '<div class="window-footer buttonctr pull-right">';
                btn.forEach(function (v, i) {
                    message += '<button class="clear-confirm k-button" onclick="' + v.action + '">' + v.text + '</button>';
                })
                message += "</div>";
            }
            $("#messagecontent").html(message);
            if (!wd) {
                wd = $("#messagebox").kendoWindow({
                    width: "600px",
                    title: title,
                    draggable: false,
                    modal: true,
                    position: "relative",
                    top: "50px",
                }).data("kendoWindow");
            }
            else {
                wd.title(title)
            }
            wd.center().open();
            Ajax.Busy.Overlay.show();
        },
        YesNoShowMessage: function (message, title, btn1, btn2) {
            var wd = $("#messagebox").data("kendoWindow");
            message = '<p class="clear-message">' + message + '</p>';
            if (btn1 && btn1.length > 0) {
                message += '<div class="window-footer buttonctr pull-right">';
                btn1.forEach(function (v, i) {
                    message += '&nbsp;&nbsp;<button class="clear-confirm k-button" onclick="' + v.action + '">' + v.text + '</button>';
                })
                message += "</div>&nbsp;&nbsp;";
            }
            if (btn2 && btn2.length > 0) {
                message += '<div class="window-footer buttonctr pull-right">';
                btn2.forEach(function (v, i) {
                    message += '<button class="clear-confirm k-button" onclick="' + v.action + '">' + v.text + '</button>';
                })
                message += "</div>&nbsp;";
            }
            $("#messagecontent").html(message);
            if (!wd) {
                wd = $("#messagebox").kendoWindow({
                    width: "600px",
                    title: title,
                    draggable: false,
                    modal: true,
                    position: "relative",
                    top: "50px",
                }).data("kendoWindow");
            }
            else {
                wd.title(title)
            }
            wd.center().open();
        },
        YesNoShowMessageWithoutClose: function (message, title, btn1, btn2) {
            var wd = $("#messagebox").data("kendoWindow");
            message = '<p class="clear-message">' + message + '</p>';
            if (btn1 && btn1.length > 0) {
                message += '<div class="window-footer buttonctr pull-right">';
                btn1.forEach(function (v, i) {
                    message += '&nbsp;&nbsp;<button class="clear-confirm k-button" onclick="' + v.action + '">' + v.text + '</button>';
                })
                message += "</div>&nbsp;&nbsp;";
            }
            if (btn2 && btn2.length > 0) {
                message += '<div class="window-footer buttonctr pull-right">';
                btn2.forEach(function (v, i) {
                    message += '<button class="clear-confirm k-button" onclick="' + v.action + '">' + v.text + '</button>';
                })
                message += "</div>&nbsp;";
            }
            $("#messagecontent").html(message);
            if (!wd) {
                wd = $("#messagebox").kendoWindow({
                    width: "600px",
                    title: title,
                    draggable: false,
                    modal: true,
                    actions: [],
                    position: "relative",
                    top: "50px",
                }).data("kendoWindow");
            }
            else {
                wd.title(title)
            }
            wd.center().open();
        },
        ConfirmDialog: function (message, title, btn1, btn2) {
            var wd = $("#messagebox").data("kendoWindow");
            message = '<p class="clear-message">' + message + '</p>';
            message += '<div class="window-footer buttonctr pull-right">';
            message += '&nbsp;&nbsp;<button class="clear-confirm k-button btn1">' + btn1.text + '</button>';
            message += "</div>&nbsp;&nbsp;";
            message += '<div class="window-footer buttonctr pull-right">';
            message += '<button class="clear-confirm k-button btn2">' + btn2.text + '</button>';
            message += "</div>&nbsp;";
            $("#messagecontent").html(message);
            if (!wd) {
                wd = $("#messagebox").kendoWindow({
                    width: "600px",
                    title: title,
                    draggable: false,
                    modal: true,
                    position: "relative",
                    top: "50px",
                }).data("kendoWindow");
            }
            else {
                wd.title(title)
            }
            $("#messagebox").find('.btn1').click(function () {
                btn1.action();
            });
            $("#messagebox").find('.btn2').click(function () {
                btn2.action();
            });
            wd.center().open();
        },
        ClosePopup: function () {
            var wd = $("#messagebox").data("kendoWindow");
            wd.close();
        },
        StringDateToTimeZone: function (dt) {
            var dateWithTimeZone = new Date(parseInt(dt));
            return this.ConvertToTimeZone(dateWithTimeZone);
        },
        ConvertToTimeZone: function (dt) {
            return dt;
        },
        ConvertFromIsoStringToDate: function (dt) {
            return new Date(dt);
        },
        getCurrentDateTime: function () {
            var dt = new Date();
            var diffInTimeZone = seal.timeZone.offset * 60 + dt.getTimezoneOffset();
            dt = new Date(dt.getTime() + diffInTimeZone * 60 * 1000);
            return dt;
        },
        isoDateRegex: /^(\d\d\d\d)-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)(\.\d\d?\d?\d?\d?\d?\d?)?([\+-]\d\d:\d\d|Z)?$/,
        DecodeJsonObject: function (gs) {
            var _ = gs.length !== undefined ? [] : {};
            var isoDateRegex = this.isoDateRegex;
            for (var a in gs) {
                if (isoDateRegex.test(gs[a])) {
                    _[a] = this.ConvertFromIsoStringToDate(gs[a]);
                }
                else if (!isoDateRegex.test(gs[a]) && gs[a] && gs[a].substr
                    && gs[a].indexOf('Date') > -1 && !isNaN(new Date(parseInt(gs[a].substr(6))))) {
                    _[a] = this.StringDateToTimeZone(gs[a].substr(6));
                }
                else if (typeof (gs[a]) != "function" && a && a.indexOf('_') < 0 && gs.hasOwnProperty(a)) {
                    if (gs[a] != null && typeof (gs[a]) == typeof ({}) && !isoDateRegex.test(gs[a])) {
                        if (!isNaN(parseInt(a))) { _.push(this.DecodeJsonObject(gs[a])); }
                        else {
                            _[a] = this.DecodeJsonObject(gs[a]);
                        }
                    }
                    else {
                        if (isoDateRegex.test(gs[a])) {
                            _[a] = new Date(gs[a]);
                            _[a] = new Date(_[a].getTime() + (_[a].getTimezoneOffset() * 60000))
                            _[a] = kendo.toString(_[a], seal.common.dateformat)
                            _[a] = _[a] && _[a].indexOf && _[a].indexOf("0001") > -1 ? "" : _[a];
                        }
                        else { _[a] = gs[a] == null ? '' : gs[a]; }
                    }
                }
            }
            return _;
        },
        CloneObject: function () {
        },
        kendoExtension: function () {
            kendo.data.binders.widget.open = kendo.data.Binder.extend({
                init: function (widget, bindings, options) {
                    //call the base constructor
                    kendo.data.Binder.fn.init.call(this, widget.element[0], bindings, options);
                    var wdw = kendo.widgetInstance($(this.element));
                    var that = this;
                    if (wdw) {
                        wdw.bind("close", function (e) {
                            that.onClose();
                        });
                    }
                },
                isInit: true,
                refresh: function () {
                    if (!this.isInit) {
                        var that = this,
                            value = that.bindings["open"].get();
                        var wdw = kendo.widgetInstance($(that.element));
                        if (wdw) {
                            if (value === true) { wdw.center(); wdw.open(); }
                            else { wdw.close(); }
                        }
                    }
                    this.isInit = false;
                },
                onClose: function () {
                    this.bindings["open"].set(false);
                }
            });
            kendo.data.binders.widget.timeformat = kendo.data.Binder.extend({
                init: function (widget, bindings, options) {
                    //call the base constructor
                    var that = this;
                    kendo.data.Binder.fn.init.call(this, widget.element[0], bindings, options);
                    var dp = kendo.widgetInstance($(this.element)),
                        value = that.bindings["timeformat"].get();

                    if (dp) {
                        dp.setOptions({
                            timeFormat: seal.format.time
                        });
                    }
                },
                refresh: function () {

                }
            });
            kendo.data.binders.widget.max = kendo.data.Binder.extend({
                init: function (widget, bindings, options) {
                    //call the base constructor
                    kendo.data.Binder.fn.init.call(this, widget.element[0], bindings, options);
                },
                refresh: function () {
                    var that = this,
                        value = that.bindings["max"].get(); //get the value from the View-Model
                    value = typeof (value) == "string" ? new Date(value) : value;
                    value = value && !isNaN(value) ? value : new Date(2099, 12, 31);
                    if ($(that.element).data("kendoDatePicker")) {
                        $(that.element).data("kendoDatePicker").max(value); //update the widget
                    }
                    if ($(that.element).data("kendoTimePicker")) {
                        $(that.element).data("kendoTimePicker").max(value); //update the widget
                    }
                }
            });
            kendo.data.binders.widget.min = kendo.data.Binder.extend({
                init: function (widget, bindings, options) {
                    //call the base constructor
                    kendo.data.Binder.fn.init.call(this, widget.element[0], bindings, options);
                },
                refresh: function (e) {
                    var that = this,
                        value = that.bindings["min"].get(); //get the value from the View-Model
                    value = typeof (value) == "string" ? new Date(value) : value;
                    value = value && !isNaN(value) ? value : new Date(1000, 01, 01);
                    if ($(that.element).data("kendoDatePicker")) {
                        $(that.element).data("kendoDatePicker").min(value); //update the widget
                    }
                    if ($(that.element).data("kendoTimePicker")) {
                        $(that.element).data("kendoTimePicker").min(value); //update the widget
                    }
                }
            });
        },
        extend: function (c, m) {
            for (var d in c) {
                if (typeof (m[d]) != "string" && (typeof (m[d]) === "array" || ((m[d] && m[d].hasOwnProperty("length"))))) {
                    c[d] = w.common.DecodeJsonObject(m[d]);
                } else
                    if (typeof (m[d]) === "object") {
                        if (!isNaN(new Date(m[d])))
                            c[d] = kendo.toString(m[d], w.common.datetimeformat);
                        else
                            this.extend(c[d], m[d]);
                    } else {
                        c[d] = m[d];
                    }
            }
            return c;
        },
        excelexport: function (e) {
            var sheet = e.workbook.sheets[0];
            for (var rowIndex = 1; rowIndex < sheet.rows.length; rowIndex++) {
                var row = sheet.rows[rowIndex];
                for (var cellIndex = 0; cellIndex < row.cells.length; cellIndex++) {
                    if ($.type(row.cells[cellIndex].value) === $.type(new Date())) {
                        year = row.cells[cellIndex].value.getFullYear();
                        if (year != "0001") {
                            row.cells[cellIndex].format = "dd-MMM-yyyy"
                        }
                        else {
                            row.cells[cellIndex].value = "";
                        }
                    }
                }
            }
        },

        dateValidation: function () {
            function startChange() {
                var startDate = start.value(),
                    endDate = end.value();

                if (startDate) {
                    startDate = new Date(startDate);
                    startDate.setDate(startDate.getDate());
                    end.min(startDate);
                } else if (endDate) {
                    start.max(new Date(endDate));
                } else {
                    endDate = seal.common.getCurrentDateTime();
                    start.max(endDate);
                    end.min(endDate);
                }
            }

            function endChange() {
                var endDate = end.value(),
                    startDate = start.value();
                if (endDate) {
                    endDate = new Date(endDate);
                    endDate.setDate(endDate.getDate());
                    start.max(endDate);
                } else if (startDate) {
                    end.min(new Date(startDate));
                } else {
                    endDate = seal.common.getCurrentDateTime();
                    start.max(endDate);
                    end.min(endDate);
                }
            }

            var start = $("#ValidFrom").kendoDatePicker({
                change: startChange
            }).data("kendoDatePicker");

            var end = $("#ValidTo").kendoDatePicker({
                change: endChange
            }).data("kendoDatePicker");

            start.max(end.value());
            end.min(start.value());
        },
        dateValidationById: function (from, to) {
            function startChange() {
                var startDate = start.value(),
                    endDate = end.value();

                if (startDate) {
                    startDate = new Date(startDate);
                    startDate.setDate(startDate.getDate() + 1);
                    end.min(startDate);
                } else if (endDate) {
                    start.max(new Date(endDate));
                } else {
                    endDate = seal.common.getCurrentDateTime();
                    start.max(endDate);
                    end.min(endDate);
                }
            }

            function endChange() {
                var endDate = end.value(),
                    startDate = start.value();

                if (endDate) {
                    endDate = new Date(endDate);
                    endDate.setDate(endDate.getDate() - 1);
                    start.max(endDate);
                } else if (startDate) {
                    end.min(new Date(startDate));
                } else {
                    endDate = seal.common.getCurrentDateTime();
                    start.max(endDate);
                    end.min(endDate);
                }
            }

            var start = $(from).kendoDatePicker({
                change: startChange
            }).data("kendoDatePicker");

            var end = $(to).kendoDatePicker({
                change: endChange
            }).data("kendoDatePicker");

            start.max(end.value());
            end.min(start.value());
        },
        formatdatetime: function (v, hastime) {
            if (v instanceof Date) {
                return kendo.toString(v, w.common[hastime ? "datetimeformat" : "dateformat"]);
            }
            if (seal.common.isoDateRegex
                && seal.common.isoDateRegex.test(v)) {
                var stringDate = kendo.toString(new Date(v), seal.common[hastime ? "datetimeformat" : "dateformat"])
                if (stringDate.indexOf('01/Jan/0001') > -1) {
                    return '';
                }
                return stringDate;
            }
            if (!v || v == "/Date(-62135596800000)/") {
                return kendo.toString('');
            }

            var dt = seal.common.StringDateToTimeZone(v.substr(6));
            return kendo.toString(dt, w.common[hastime ? "datetimeformat" : "dateformat"]);
        },

        concatcodedescription: function (code, desc) {
            var value = code + " - " + desc;
            return "<span title='" + code + "'>" + value + "</span>";
        },

        formatdescription: function (data) {
            length = seal.common.constants.descriptionLenth;
            if (data) {
                var value = data.length > length ? data.substring(0, length) + "..." : data;
                return "<span title='" + data + "'>" + value + "</span>";
            }
            else {
                return "";
            }
        },

        gridtitledescription: function (data) {         //FIX FOR TOOL TIP AS OF NOW.
            length = seal.common.constants.titleLenth;
            if (data) {
                var value = data.length > length ? data.substring(0, length) + "..." : data;
                return "<span title='" + data + "'>" + value + "</span>";
            }
            else {
                return "";
            }
        },

        customformatdescription: function (data, datalength) {
            length = datalength;
            if (data) {
                var value = data.length > length ? data.substring(0, length) + "..." : data;
                return "<span title='" + data + "'>" + value + "</span>";
            }
            else {
                return "";
            }
        },
        router: function (p) {
            var inRouter = new kendo.Router(p);
            this.route = function (r, fn) { inRouter.route(r, fn); }
            this.destroy = function (u) { inRouter.destroy(); }
            this.navigate = function (u) {
                inRouter.start();
                inRouter.navigate(u);
            }
        },
        getid: function (id) {
            if (typeof (id) === "string")
                return (id[0] == "#" ? "" : "#") + id;
            return id;
        },
        getajax: function (url, data, id) {
            $.ajax({
                url: url,
                data: data,
                type: "get",
                global: false,
                cache: false,
                success: function (data) {
                    $(w.common.getid(id)).html(data);
                },
                error: function (data) {
                }
            })
        },
        loadingpanel: function (t) {
            $("#loadingpanel")[t ? "show" : "hide"]();
        },
        message: function (title, msg, btn) {
            var showaction = !0;
            var wd = $("#messagebox").data("kendoWindow");
            msg = '<p class="clear-message">' + msg + '</p>';
            if (btn && btn.length > 0) {
                msg += '<div class="window-footer buttonctr pull-right">';
                btn.forEach(function (v, i) {
                    msg += '<button class="clear-confirm k-button" onclick="' + (v.isclose ? "seal.common.close()" : v.action) + '">' + v.text + '</button>';
                })
                msg += "</div>";
                showaction = !1;
            }

            $("#messagecontent").html(msg);
            if (!wd) {
                wd = $("#messagebox").kendoWindow({
                    width: "600px",
                    title: title,
                    modal: true,
                    draggable: false,
                }).data("kendoWindow");
            }
            else {
                wd.title(title)
            }
            wd.wrapper.children('.k-window-titlebar:first-child')
                .dblclick(function (e) {
                    e.preventDefault();
                    return false;
                });
            wd.open().center();
            $(wd.wrapper[0]).find(".k-window-action")[showaction ? "show" : "hide"]();
        },
        close: function () {
            var wd = $("#messagebox").data("kendoWindow");
            Ajax.Busy.Overlay.hide();
            if (wd !== undefined
                && wd !== null) {
                wd.close();
            }

        },
        afterinit: function () {
            $("input").attr("autocomplete", "off");     // To hide the cache records. this should put in document ready          
            $("[data-role=datepicker]").not('.nocustombehave').on("change", function (e) {
                var datePicker = $(e.currentTarget).data("kendoDatePicker");
                var val = e.currentTarget.value;
                var currentDate = kendo.parseDate(val.trim(), datePicker.options.format);
                var find = '/';
                var re = new RegExp(find, 'g');
                val = val.replace(re, ' ');
                if (!currentDate || currentDate == "Invalid Date" || val.length !== datePicker.options.format.length) {
                    datePicker.element.val("");
                }
                else {
                    if (datePicker.options.min && datePicker.options.max) {
                        if (new Date(val) < new Date(datePicker.options.min.setHours(0, 0, 0, 0, 0)) || new Date(val) > datePicker.options.max.setHours(0, 0, 0, 0, 0)) {
                            datePicker.element.val("");
                        }
                    }
                }
            });
            $("[data-role=datetimepicker]").not('.nocustombehave').on("focusout", function (e) {
                var datePicker = $(e.currentTarget).data("kendoDateTimePicker");
                var val = e.currentTarget.value;
                var currentDate = kendo.parseDate(val.trim(), datePicker.options.format);
                var find = '/';   ///Toreplace the / to work in IE
                var re = new RegExp(find, 'g');
                val = val.replace(re, ' ');
                if (!currentDate || currentDate == "Invalid Date" || val.length !== datePicker.options.format.length) {
                    datePicker.element.val("");
                }
                else {
                    if (datePicker.options.min && datePicker.options.max) {
                        if (new Date(val) < new Date(datePicker.options.min) || new Date(val) > datePicker.options.max) {
                            datePicker.element.val("");
                        }
                    }
                }
                seal.validation.EventHandler.OnChange(e);
            })
            $("[data-role=combobox]").not('.nocustombehave').on("focusout", function (e) {
                var combobox = $(e.currentTarget).data("kendoComboBox");
                if (combobox && combobox.dataItem() === undefined) {
                    if (combobox.text) { combobox.text(''); }
                    if (combobox.value) { combobox.value(''); }
                    combobox.wrapper.find('input').removeAttr('title');
                    seal.validation.EventHandler.OnChange(e);
                }
            });
            $('input[type=text]').change(function () {
                $("input").attr("autocomplete", "off");
            })

            $('.k-window-titlebar:first-child')
                .dblclick(function (e) {
                    e.preventDefault();
                    return false;
                });
            var win = $("[data-role='window']").getKendoWindow();
            win ? win.center() : "";
        },

        commonAdvanceSearch: function (path, header, popupheader) {
            if (popupheader == null) {
                popupheader = "Equipment Advance Search";
            }
            $('#modalheader').html(popupheader);
            $("#btnAdvSearch").trigger('click');

            Ajax.Request({
                url: path,
                type: "GET",
                cache: false,
                success: function (data) {
                    $("#advancesearchpopup").html(data);
                    seal.common.afterinit();
                },
                error: function (data) {
                    seal.common.ShowMessage(data.message, header, [{ text: seal.common.constants.btnOk, action: "seal.common.close()" }]);
                }
            });
        },
        commonAdvanceSearchAsPost: function (path, header, popupheader, data) {
            if (popupheader == null) {
                popupheader = "Equipment Advance Search";
            }
            $('#modalheader').html(popupheader);
            $("#btnAdvSearch").trigger('click');

            Ajax.Request({
                url: path,
                type: "POST",
                data: data,
                cache: false,
                success: function (data) {
                    $("#advancesearchpopup").html(data);
                    seal.common.afterinit();
                },
                error: function (data) {
                    seal.common.ShowMessage(data.message, header, [{ text: seal.common.constants.btnOk, action: "seal.common.close()" }]);
                }
            });
        },

        clienterror: function (request, title) {
            try {
                if (request.xhr.responseText &&
                    request.xhr.responseText.indexOf("Server Error") > -1) {
                    seal.common.ShowMessage("Internal Server Error", title);
                    console.log(request.xhr.responseText);
                }
                else {
                    seal.common.ShowMessage(request.xhr.responseText, title);
                }
            } catch (error) {
                console.log(error);
                console.log(request.xhr.responseText);
            }
        },

        commonAdvanceSearchwithoutclose: function (path, header, popupheader) {

            $('#limitmodal').html(popupheader);
            $("#limitPopUp").trigger('click');

            Ajax.Request({
                url: path,
                type: "GET",
                cache: false,
                success: function (data) {
                    $("#limitpopup").html(data);
                    seal.common.afterinit();
                },
                error: function (data) {
                    seal.common.ShowMessage(data.message, header, [{ text: seal.common.constants.btnOk, action: "seal.common.close()" }]);
                }
            });
        },

        splitvalues: function (value) {
            if (value) {
                return "<div>" + value.Code + "</div>"
            }
            return "";
        },

        getStatus: function (value) {
            var cssClass; var display;
            if (value == 'A') {
                cssClass = 'label label-success';
                display = seal.common.constants.txtActive;
            }
            if (value == 'I') {
                cssClass = 'label label-failure, inactive';
                display = seal.common.constants.txtInactive;
            }

            if (value == 'Pending') {
                cssClass = 'label label-failure, inactive';
                display = "Pending";
            }
            if (value == 'Active') {
                cssClass = 'label label-success';
                display = seal.common.constants.txtActive;
            }
            if (value == 'InActive' || value == 'Inactive') {
                cssClass = 'label label-failure, inactive';
                display = seal.common.constants.txtInactive;
            }
            if (value == 'Deleted') {
                cssClass = 'label label-failure, inactive';
                display = seal.common.constants.txtInactive;
            }

            return "<div class='" + cssClass + "'>" + display + "</div>"
        },


        getDocumentStatus: function (value) {
            var cssClass; var display;
            if (value == 'A') {
                cssClass = 'label label-success';
                display = 'Customs Approved';
            }
            if (value == 'D') {
                cssClass = 'label label-success';
                display = 'Draft';
            }

            if (value == 'F') {
                cssClass = 'label label-success';
                display = 'Draft';
            }

            if (value == 'F') {
                cssClass = 'label label-success';
                display = 'Draft';
            }
            if (value == 'P') {
                cssClass = 'label label-failure, inactive';
                display = 'Pending';
            }

            if (value == 'O') {
                cssClass = 'label label-failure, inactive';
                display = 'Container/Cargo Gated Out';
            }

            if (value == 'C') {
                cssClass = 'label label-failure, inactive';
                display = 'Cancelled';
            }

            return "<div class='" + cssClass + "'>" + display + "</div>"
        },

        getMSCOwnedStatus: function (value) {
            var display;
            if (value) {
                display = seal.common.constants.txtYes;
            }
            else {
                display = seal.common.constants.txtNo;
            }

            return "<div>" + display + "</div>"
        },
        zeroFill: function (i) {
            return (i < 10 ? '0' : '') + i
        },
        urlencode: function (text) {
            return encodeURIComponent(text).replace(/!/g, '%21')
                                           .replace(/'/g, '%27')
                                           .replace(/\(/g, '%28')
                                           .replace(/\)/g, '%29')
                                           .replace(/\*/g, '%2A')
                                           .replace(/%20/g, '+');
        },
        JsonParse: function (obj) {
            return JSON.parse(obj.replace(/\t/g, '\\t').replace(/\n/g, '\\n').replace(/\r/g, '\\r'))
        },
        gridSelectedItemIndex: function (grid) {
            var rowIndex = grid.select().closest("tr").index();
            var pageSize = grid.dataSource.pageSize();
            var pageIndex = grid.dataSource.page();
            return index = (pageSize * (pageIndex - 1)) + rowIndex;
        },

    }
    w.common.init();

    w.page = function (DuplicateMsg, rowId, GRIDID, Key, MessageHeader) {
        return {
            IsVisibleChildEntry: false,
            IsAddVisible: false,
            IsUpdateVisible: false,
            IsInEditMode: true,
            DuplicateMsg: DuplicateMsg,
            rowId: rowId,
            rowIndex: 0,
            GRIDID: GRIDID,
            Key: Key,
            MessageHeader: MessageHeader,
        };
    };
    //-------------------------------------------Child Entiry Manupulation Template --------------------------------------------------
    w.pageTemplate =
        {
            addNewToggle: function (pageModel, key) {
                that = pageModel;
                that[key].page.set("IsVisibleChildEntry", !0);
                that[key].page.set("IsAddVisible", !0);
                that[key].page.set("IsUpdateVisible", !1);
            },
            ediToggle: function (pageModel, key) {
                that = pageModel;
                that[key].page.set("IsVisibleChildEntry", !0);
                that[key].page.set("IsAddVisible", !1);
                that[key].page.set("IsUpdateVisible", !0);
            },
            addToggle: function (pageModel, key) {
                that = pageModel;
                that[key].page.set("IsVisibleChildEntry", !1);
                that[key].page.set("IsAddVisible", !1);
                that[key].page.set("IsUpdateVisible", !1);
            },
            addNew: function (pageModel, key, uiValidation) {
                this.addNewToggle(pageModel, key);
                this.loadValidation(uiValidation);
            },
            add: function (pageModel, key, listSource, source, uiValidation) {
                that = pageModel;
                that[key].page.rowId += 1;
                source.Id = that[key].page.rowId;
                let outCome = { isValid: true };
                if (uiValidation.Category != null) {
                    outCome = seal.validation.IsValid(uiValidation.Category);
                }
                if (that[key].isDuplicateEntry()) {
                    outCome.isValid = !1;
                    outCome.message += that[key].page.DuplicateMsg;
                }
                if (that[key].checkManulMandatory != undefined) {
                    let result = that[key].checkManulMandatory();
                    if (!result.isValid) {
                        outCome.isValid = result.isValid;
                        outCome.message += result.message;
                    }
                }
                if (outCome.isValid) {
                    source.RowStatus = seal.common.recordRowStatus.Added;
                    listSource.push(source);
                    this.addToggle(pageModel, key);
                }
                else {
                    seal.common.ShowMessage(outCome.message, that[key].page.MessageHeader);
                }
            },
            update: function (pageModel, key, listSource, source, uiValidation) {
                that = pageModel;
                let outCome = { isValid: true };
                if (uiValidation.Category != null) {
                    outCome = seal.validation.IsValid(uiValidation.Category);
                }
                if (that[key].isDuplicateEntry()) {
                    outCome.isValid = !1;
                    outCome.message += that[key].DuplicateMsg;
                }
                if (that[key].checkManulMandatory != undefined) {
                    let result = that[key].checkManulMandatory();
                    if (!result.isValid) {
                        outCome.isValid = result.isValid;
                        outCome.message += result.message;
                    }
                }
                if (outCome.isValid) {
                    if (source.RowStatus != seal.common.recordRowStatus.Added) {
                        source.RowStatus = seal.common.recordRowStatus.Modified;
                    }
                    let index = that[key].page.rowIndex;

                    //let orgSource = listSource[index];
                    let orgSource = listSource.find(function (d) { return d.Id == that[key].rowId });
                    for (propname in orgSource) {
                        if (propname != "_handlers" && propname != "_events") {
                            orgSource.set(propname, source[propname]);
                        }
                    }
                    this.addToggle(pageModel, key);
                }
                else {
                    seal.common.ShowMessage(outCome.message, that[key].page.MessageHeader);
                }
            },
            delete: function (pageModel, key, listSource, listremovedSource) {
                that = pageModel;
                let rowIndex = that[key].page.rowIndex;
                //let removedItem = listSource[rowIndex];
                let removedItem = listSource.find(function (d) { return d.Id == that[key].rowId });
                if (removedItem.RowStatus != seal.common.recordRowStatus.Added) {
                    removedItem.RowStatus = seal.common.recordRowStatus.Deleted;
                    listremovedSource.push(removedItem);
                }
                listSource.splice(rowIndex, 1);
                this.addToggle(pageModel, key);
            },
            edit: function (pageModel, key, listSource, source, uiValidation) {
                that = pageModel;
                var grid = $(that[key].page.GRIDID).data("kendoGrid");
                var rowIndex = grid.select().closest("tr").index();
                that[key].page.set("rowIndex", rowIndex);
                that[key].rowId = grid.dataItem(grid.select()).Id;

                //editObject = listSource[rowIndex];
                editObject = listSource.find(function (d) { return d.Id == that[key].rowId });
                let newObj = JSON.parse(JSON.stringify(editObject));
                for (cpykey in newObj) {
                    source.set(cpykey, newObj[cpykey]);
                }
                this.ediToggle(pageModel, key);
                this.loadValidation(uiValidation);
            },
            loadValidation: function (uiValidation) {
                var VH = seal.validation;
                var category = seal.validation.Category.Add(uiValidation.Category, uiValidation.DivId, uiValidation.ProcessCode, uiValidation.Sequence);
                VH.Load({ category: uiValidation.Category });
            },
        };

    //-------------------------------------------Child Entiry Manupulation Template --------------------------------------------------

    //--------------------Dynamic validation---------------------------
    w.dynamicValidation = {
        remove: function (labelId) {
            Label = document.getElementById(labelId);
            if (Label != null) {
                Label.innerHTML = Label.innerHTML.replace(/\<span(.+)\>/g, '');
            }
        },
        addBulk: function (mandatorymsg, labelId, value) {
            let span = $('#' + labelId + ' span');
            Label = document.getElementById(labelId);
            if (Label != null) {
                Label.innerHTML = Label.innerHTML.replace(/\<span(.+)\>/g, '');
                Label.innerHTML = Label.innerHTML.replace(/\<\/label\>/g, '').trim() + '<span title="' + mandatorymsg + '" class="ValidationSummary">*</span>' + '</label>';
                this.addBulkclass(labelId, value);
            }
        },
        addBulkclass: function (labelId, value) {
            let span = $('#' + labelId + ' span');
            if (value != undefined && value != null && value != "") {
                span.removeClass('ValidationSummary');
            }
            else {
                span.addClass('ValidationSummary');
            }
        },
        add: function (mandatorymsg, labelId, value) {
            let span = $('#' + labelId + ' span');
            Label = document.getElementById(labelId);
            Label.innerHTML = Label.innerHTML.replace(/\<span(.+)\>/g, '');
            Label.innerHTML = Label.innerHTML.replace(/\<\/label\>/g, '').trim() + '<span title="' + mandatorymsg + '" class="ValidationSummary">*</span>' + '</label>';
            this.addclass(labelId, value);
        },
        addclass: function (labelId, value) {
            let span = $('#' + labelId + ' span');
            if (value != undefined && value != null && value != "") {
                span.addClass('ValidationSummary');
            }
            else {
                span.removeClass('ValidationSummary');
            }
        },
        addorremoveclass: function (labelId, value) {
            let span = $('#' + labelId + ' span');
            if (value != undefined && value != null && value != "") {
                span.removeClass('ValidationSummary');
            }
            else {
                span.addClass('ValidationSummary');
            }
        }

    };

    if (!Array.prototype.find) {
        Object.defineProperty(Array.prototype, 'find', {
            value: function (predicate) {
                // 1. Let O be ? ToObject(this value).
                if (this == null) {
                    throw new TypeError('"this" is null or not defined');
                }

                var o = Object(this);

                // 2. Let len be ? ToLength(? Get(O, "length")).
                var len = o.length >>> 0;

                // 3. If IsCallable(predicate) is false, throw a TypeError exception.
                if (typeof predicate !== 'function') {
                    throw new TypeError('predicate must be a function');
                }

                // 4. If thisArg was supplied, let T be thisArg; else let T be undefined.
                var thisArg = arguments[1];

                // 5. Let k be 0.
                var k = 0;

                // 6. Repeat, while k < len
                while (k < len) {
                    // a. Let Pk be ! ToString(k).
                    // b. Let kValue be ? Get(O, Pk).
                    // c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
                    // d. If testResult is true, return kValue.
                    var kValue = o[k];
                    if (predicate.call(thisArg, kValue, k, o)) {
                        return kValue;
                    }
                    // e. Increase k by 1.
                    k++;
                }

                // 7. Return undefined.
                return undefined;
            }
        });
    }
    if (!Array.prototype.findIndex) {
        Object.defineProperty(Array.prototype, 'findIndex', {
            value: function (predicate) {
                // 1. Let O be ? ToObject(this value).
                if (this == null) {
                    throw new TypeError('"this" is null or not defined');
                }

                var o = Object(this);

                // 2. Let len be ? ToLength(? Get(O, "length")).
                var len = o.length >>> 0;

                // 3. If IsCallable(predicate) is false, throw a TypeError exception.
                if (typeof predicate !== 'function') {
                    throw new TypeError('predicate must be a function');
                }

                // 4. If thisArg was supplied, let T be thisArg; else let T be undefined.
                var thisArg = arguments[1];

                // 5. Let k be 0.
                var k = 0;

                // 6. Repeat, while k < len
                while (k < len) {
                    // a. Let Pk be ! ToString(k).
                    // b. Let kValue be ? Get(O, Pk).
                    // c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
                    // d. If testResult is true, return k.
                    var kValue = o[k];
                    if (predicate.call(thisArg, kValue, k, o)) {
                        return k;
                    }
                    // e. Increase k by 1.
                    k++;
                }

                // 7. Return -1.
                return -1;
            }
        });
    }
    if (!Date.prototype.toDepotFormat) {
        (function () {

            function pad(number) {
                if (number < 10) {
                    return '0' + number;
                }
                return number;
            }

            Date.prototype.toDepotFormat = function () {
                return this.getFullYear() +
                    '-' + pad(this.getMonth() + 1) +
                    '-' + pad(this.getDate()) +
                    'T' + pad(this.getHours()) +
                    ':' + pad(this.getMinutes()) +
                    ':' + pad(this.getSeconds()) +
                    '.' + (this.getMilliseconds() / 1000).toFixed(3).slice(2, 5);
            };


        }());
    }

    if (!Array.prototype.unique) {
        Array.prototype.unique = function () {
            return this.filter(function (value, index, self) {
                return self.indexOf(value) === index;
            });
        }
    }

    String.prototype.toDepotFormat = function () {
        return this;
    };
}(this.seal = this.seal || {}));





