﻿seal['errorhandling'] = {
    init: function () {
        model = {};
        var self = this;
        this.omodel = this.updateModel(model);
        this.bindModel();
    },
    updateModel: function (model) {
        var self = this;
        model.showerror = self.showerror;
        model.IsErrorVisible =false;
        return seal.observable(model);
    },
    showerror: function(e)
    {
        var text = $.trim(e.currentTarget.innerText);
        if (text === "Show Stack Trace") {
            e.currentTarget.innerHTML = "<i class='fa fa-angle-double-up' aria-hidden='true'></i>&nbsp; " + "Hide Stack Trace";
            seal.errorhandling.omodel.set("IsErrorVisible", true);
        } else {
            e.currentTarget.innerHTML = "<i class='fa fa-angle-double-down' aria-hidden='true'></i>&nbsp; " + "Show Stack Trace";
            seal.errorhandling.omodel.set("IsErrorVisible", false);
        }
       
    } ,
    bindModel: function () {
        seal.bind("#ErrorHandlingPage", this.omodel);
    },
};