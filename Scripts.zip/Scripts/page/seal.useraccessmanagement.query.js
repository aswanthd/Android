﻿seal['useraccessedit'] = {
    init: function (arg) {
        this.url = arg.url;
        this.constant = arg.constant;
        this.msg = arg.msg;
        this.omodel = this.updateModel(arg.model);
        seal.admin.handleGrants("#UserManagementEntry");
        this.bindModel();
        var key = 'UserAccessManagement_' + this.omodel.Id;
        StateManager.ReadRecord(key);
    },
    page: '#UserManagementEntry',
    grid: '#DepotDetailsTariffGrid',
    url: {},
    constant: {},
    msg: {},
    source: function (obj) {
        return new kendo.data.DataSource({
            pageSize: obj.pageSize || 30,
            pageable: true,
            serverPaging: true,
            serverFiltering: true,
            transport: {
                read: {
                    url: obj.url,
                    type: "GET",
                    dataType: "json",
                    data: obj.data || function () {
                        return {
                            search: ''
                        };
                    },
                },
            },
            schema: {
                total: "Total", 
                data: "Data"
            },
            error: function (request) {
                seal.common.clienterror(request, "User Access Management");
            },
        });
    },
    omodel: {
    },
    recordRowStatus: {
        Unchanged: 0,
        Added: 1,
        Modified: 2,
        Deleted: 3,
    },
    updateModel: function (model) {
        var currentItem = this;
        model = seal.common.DecodeJsonObject(model);
        model.Statuses = currentItem.source({ url: currentItem.url.searchGeneralCodes + '?reference=' + currentItem.constant.STATUSCODE });
        model.searchdepartments = currentItem.source({ url: currentItem.url.searchGeneralCodes + '?reference=' + currentItem.constant.DEPARTMENTCODE });
        model.SearchRegions = currentItem.source({ url: currentItem.url.searchRegionNames });
        model.SearchDepotName = currentItem.source({ url: currentItem.url.searchDepotNames });
        model.SearchModuleName = currentItem.source({ url: currentItem.url.SearchModuleName });
        model.SearchPrograms = currentItem.source({ url: currentItem.url.SearchProgramName });
        model.SearchRights = currentItem.source({ url: currentItem.url.SearchRights });
        model.IsVisibleDepotGrid = true;
        model.IsVisibleDepotEntry = false;
        model.IsDepotAddVisible = true;
        model.IsDepotUpdateVisible = false;
        model.AccessRightsGridClick = currentItem.AccessRightsGridClick;
        model.edit = currentItem.edit;
        model.IsVisibleAccessDetailsGrid = true;
        model.IsVisibleAccessRightsEntry = false;
        model.IsAccessRightsAddVisible = true;
        model.IsAccessRightsUpdateVisible = false;
        model.cpyAccessDetails = model.AccessDetails;
        model.addNewDepotDetails = currentItem.addNewDepotDetails;
        model.confirmcancel = currentItem.confirmcancel;
        model.depotentrycancel = currentItem.depotentrycancel;
        model.addDepotDetails = currentItem.addDepotDetails;
        model.cpyDepotDetails = model.DepotDetails;
        model.addNewAccessDetails = currentItem.addNewAccessDetails;
        model.addAccessRightsDetails = currentItem.addAccessRightsDetails;
        model.AccessRightsentrycancel = currentItem.AccessRightsentrycancel;
        model.newDepotItemId = 0;
        model.newAccessItemId = 0;
        model.DepotGridClick = currentItem.DepotGridClick;
        model.confirmdepotdelete = currentItem.depotdelete;
        model.depotupdate = currentItem.depotupdate;
        model.CurrentRowDepotIndex = 0;
        model.CurrentRowAccessIndex = 0;
        model.featuregridClick = currentItem.featuregridClick;
        model.ShowAccessRigths = currentItem.ShowAccessRigths;
        return seal.observable(model);
    },
    getLockKey: function () {
        return 'UserAccessManagement_' + seal.useraccessedit.omodel.Id;
    },
    edit: function()
    {
        StateManager.LockRecord(seal.useraccessedit.getLockKey(), function () {
            seal.loader.navigate(seal.useraccessedit.url.edit + "?id=" + seal.useraccessedit.omodel.Id);
        }, []);
    }, 
    AccessRightsGridClick : function(e)
    {
        var grid = $("#AccessRightsGrid").data("kendoGrid");
        var rowIndex = grid.select().closest("tr").index();
        UserAccessList = seal.useraccessedit.omodel.AccessDetails[rowIndex];
        seal.useraccessedit.omodel.AccessDetail.set("Module.Module", UserAccessList.Module);
        seal.useraccessedit.omodel.AccessDetail.set("Depot.Depot", UserAccessList.Depot);
        seal.useraccessedit.omodel.AccessDetail.set("Menu.Menu", UserAccessList.Menu);
        seal.useraccessedit.omodel.set("CurrentRowAccessIndex", rowIndex);
        seal.useraccessedit.omodel.set("IsAccessRightsAddVisible", false);
        seal.useraccessedit.omodel.set("IsAccessRightsUpdateVisible", true);
        seal.useraccessedit.omodel.set("IsVisibleAccessDetailsGrid", false);
        seal.useraccessedit.omodel.set("IsVisibleAccessRightsEntry", true);
    },
    DepotGridClick: function (e) {
        var grid = $(seal.useraccessedit.grid).data("kendoGrid");
        var rowIndex = grid.select().closest("tr").index();
        UserAccessList = seal.useraccessedit.omodel.DepotDetails[rowIndex];
        seal.useraccessedit.omodel.DepotDetail.set("Id", UserAccessList.Id);
        seal.useraccessedit.omodel.DepotDetail.set("Region", UserAccessList.Region);
        seal.useraccessedit.omodel.DepotDetail.set("Depot.Depot", UserAccessList.Depot);
        seal.useraccessedit.omodel.set("CurrentRowDepotIndex", rowIndex);
        seal.useraccessedit.omodel.set("IsDepotAddVisible", false);
        seal.useraccessedit.omodel.set("IsDepotUpdateVisible", true);
        seal.useraccessedit.omodel.set("IsVisibleDepotGrid", false);
        seal.useraccessedit.omodel.set("IsVisibleDepotEntry", true);
    },
    depotentrycancel: function(e)
    {
        seal.useraccessedit.omodel.set("IsDepotAddVisible", true);
        seal.useraccessedit.omodel.set("IsDepotUpdateVisible", false);
        seal.useraccessedit.omodel.set("IsVisibleDepotGrid", true);
        seal.useraccessedit.omodel.set("IsVisibleDepotEntry", false);
    },
    AccessRightsentrycancel: function(e)
    {
        seal.useraccessedit.omodel.set("IsAccessRightsAddVisible", true);
        seal.useraccessedit.omodel.set("IsAccessRightsUpdateVisible", false);
        seal.useraccessedit.omodel.set("IsVisibleAccessDetailsGrid", true);
        seal.useraccessedit.omodel.set("IsVisibleAccessRightsEntry", false);
    },
    confirmcancel: function () {
        seal.useraccessedit.cancel();
        return false;
    },
    clearAccess: function()
    {
        seal.useraccessedit.omodel.AccessDetail.set("Module", "");
        seal.useraccessedit.omodel.AccessDetail.set("Depot", "");
        seal.useraccessedit.omodel.AccessDetail.set("Menu", "");
        seal.useraccessedit.omodel.set("CurrentRowIndex", -1);
    },
    clearDepot: function()
    {
        seal.useraccessedit.omodel.DepotDetail.set("Region", "");
        seal.useraccessedit.omodel.DepotDetail.set("Depot.Depot", "");
        seal.useraccessedit.omodel.set("CurrentRowDepotIndex", -1);
    }, 
    ShowAccessRigths: function(e)
    {
        var grid = $("#AccessRightsGrid").data("kendoGrid");
        var selectedItem = grid.dataItem($(e.currentTarget).closest("tr"));
        seal.useraccessedit.omodel.set("Features", selectedItem.Features);
        $(".modal-link").trigger('click');
    },
    cancel: function () {
        var contentContainer = document.getElementById('contentarea');
        var searchContainer = document.getElementById('searcharea');
        if (searchContainer.innerHTML !== "") {
            contentContainer.innerHTML = "";
            contentContainer.appendChild(document.getElementById('UserAccessDiv'));
        }
        else {
            seal.loader.navigate(seal.useraccessedit.url.cancel);
        }
    },
    bindModel: function () {
        seal.bind(this.page, this.omodel);
    },
};