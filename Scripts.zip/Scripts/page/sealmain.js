﻿if (typeof (seal) === "undefined") {
    var Ajax = {
        Queue: 0,
        Busy: {
            isBusy: !1,
            container: '.image-container',
            panel: '.loadinggroup',
            covers: '#overlay',
            front: 'loading-front',
            indicator: {
                show: function () {
                    $(Ajax.Busy.container).toggleClass(Ajax.Busy.front);
                    $(Ajax.Busy.panel).show();
                },
                hide: function () {
                    $(Ajax.Busy.container).toggleClass(Ajax.Busy.front);
                    $(Ajax.Busy.panel).hide();
                }
            },
            Overlay: {
                show: function () {
                    $(Ajax.Busy.covers).show();
                },
                hide: function () {
                    $(Ajax.Busy.covers).hide();
                }
            },
            set: function () {
                if (!this.isBusy) { this.indicator.show(); }
                this.isBusy = !0;
            },
            setmessage: function () {
                if (!this.isBusy) {
                    this.indicator.show();
                }
                this.isBusy = !0;
            },
            reset: function () {
                this.isBusy = !1;
                this.indicator.hide();
            }
        },
        GetHeaders: function () {
            var headers = {};
            var reqToken = document.getElementsByName('__RequestVerificationToken');
            if (reqToken.length > 0) {
                headers['__RequestVerificationToken'] = reqToken[0].value;
            }
            return headers;
        },
        AddCsrfToken: function (xhr) {
            var hdr = Ajax.GetHeaders();
            var tkname = '__RequestVerificationToken';
            xhr.setRequestHeader(tkname, hdr[tkname]);
        },
        HttpStatus: {
                Forbidden: 403
        },
        EncodeJsonObject: function (gs) {
            var self = this;
            for (var a in gs) {
                if (typeof (gs[a]) !== "function"
                    && gs.hasOwnProperty(a)
                    && gs[a] !== undefined
                    && gs[a] !== null) {
                    if (gs[a] instanceof Array) {
                        gs[a].forEach(function (child) {
                            self.EncodeJsonObject(child);
                        });
                    }
                    if (gs[a] instanceof Object) {
                        this.EncodeJsonObject(gs[a]);
                    }
                    if (seal.common.isoDateRegex.test(gs[a])
                        && gs[a].indexOf('Z') > -1) {
                        var dt = new Date(gs[a]);
                        if (dt !== undefined) {
                            gs[a] = dt.toDepotFormat();
                        }
                    }
                }
            }
            return gs;
        },
        fixDateFormat: function (data) {
            try {
                if (data !== undefined) {
                    return this.EncodeJsonObject(data);
                }
                return data;
            }
            catch (error) {
                console.log(error);
                return data;
            }
        },
        ai: function (request) {
            try {
                if (request.url
                    && (request.url.toUpperCase().indexOf('SAVE') > -1
                    || request.url.toUpperCase().indexOf('UPDATE') > -1)) {
                    var withoutQueryString = request.url;
                    var eventData = request.data;
                    if (request.url.indexOf('?') > -1) {
                        withoutQueryString = request.url.split('?')[0];
                        var justQueryString = request.url.split('?')[1];
                        eventData = {
                            queryString: justQueryString,
                            data: request.data
                        };
                    }                   
                    appInsights.trackEvent(withoutQueryString, eventData);
                }
            }
            catch (error){
            }
        },
        Request: function (request) {
            var self = this;
            ++this.Queue;
            self.Busy.set();
            //this.ai(request);
            this.fixDateFormat(request.data);
            $.ajax({
                url: request.url,
                type: request.type,
                contentType: request.contentType,
                cache: request.cache || false,
                data: request.data,
                headers: self.GetHeaders(),
                processData: request.processData || true,
                contentType: request.contentType || $.ajaxSettings.contentType,
                success: function (o) {
                    if (request.success) request.success(o);
                },
                error: function (error) {
                    status = 0;
                    var errorHandled = false;
                    if (typeof error != "undefined") {
                        seal.common.ShowMessage(error.responseJSON.error, error.statusText);
                    }

                    if (self.Queue > 0) { self.Busy.set(); }
                    else { self.Busy.reset(); }
                    if (request.onComplete) {
                        request.onComplete(result);
                    }
                },
                complete: function (result) {
                    --self.Queue;
                    if (self.Queue > 0) { self.Busy.set(); }
                    else { self.Busy.reset(); }
                    if (request.onComplete) {
                        request.onComplete(result);
                    }
                }
            });
        }
    };
    window['seal'] = function () {
        return {
            init: function (data) {
                this.Url = data.url;
                this.format = data.format;
                this.UserId = data.url.userId;
                this.DepotId = data.url.depotId;
                this.loader.menu();
                this.constants = data.constants;
                this.extensions();
                this.disableback();
                this.addEventlisteners();
                this.user = data.user;
                this.permissions = JSON.parse(data.featurePermission.featurePermissions);
                seal.admin.setPermission(JSON.parse(data.featurePermission.featurePermissions));
                this.timeZone = data.timeZone;
                $.ajaxSettings.cache = false;
                seal.common.dateformat = this.format.date;
                seal.common.datetimeformat = this.format.datetime;
            },
            disableback: function () {
                var doBack = function () {
                    history.pushState ? history.pushState(null, "", "#") : location.hash = "#"
                };
                doBack(),
                window.onhashchange = doBack;
            },
            timeZone: {},
            admin: function () {
                var permissions = [];
                return {
                    attribute: 'accesskey',
                    hasPermission: function (grant) {
                        return permissions.indexOf(grant) > -1;
                    },
                    setPermission: function (grants) {
                        if (permissions.length === 0) { permissions = grants; }
                    },
                    handleGrants: function (selector) {
                        var self = this;
                        //$.each($(selector).find('[' + this.attribute + ']'), function (index, btn) {
                        //    $btn = $(btn);
                        //    var grant = $btn.attr(self.attribute);
                        //    if (self.hasPermission(grant)) {
                        //        $btn.toggleClass('accessrights');                              
                        //    } else {
                        //        $btn.attr('disabled', 'disabled');
                        //        $btn.unbind('click').bind('click', function () {
                        //            alert('Acess Denied');
                        //        });
                        //    }
                        //});
                    },
                }
            }(),
            addEventlisteners: function () {
                $(window).on("unload", function () {
                    StateManager.ReleaseAllRecord();
                });
            },
            logout: function (url) {
                StateManager.ReleaseAllRecord();
                window.location.href = url;
            },
            format: {
                date: '',
                datetime: '',
                time:''
            },
            constants: {
                insert: '',
                update: '',
                deleted: '',
                unchanged: '',
            },
            getElement: function (id) {
                return kendo.widgetInstance('#' + id);
            },
            status: function (status, isdelete) {
                if (isdelete) { return this.constants.deleted; }
                if (this.constants.insert === status) { return status; }
                return this.constants.update;
            },
            isNew: function (status) {
                return status === this.constants.insert;
            },
            isDeleted: function (status) {
                return status === this.constants.deleted;
            },
            Url: {},
            UserId: {},
            createurl: function (pr) {
                var url = this.Url[pr], index = 1;
                for (; index < arguments.length; index++) {
                    url += "\\" + arguments[index];
                }
                return url;
            },
            logger: {
                isDebug: !0,
                lead: function (fn, msg) {
                    if (this.isDebug) { console[fn](msg); }
                },
                info: function (msg) {
                    this.lead('info', msg);
                },
                log: function (msg) {
                    this.lead('log', msg);
                },
                error: function (msg) {
                    this.lead('error', msg);
                },
                warning: function (msg) {
                    this.lead('warn', msg);
                }
            },
            loader: {
                cache: {
                    get: function (key) {
                        return sessionStorage.getItem(key);
                    },
                    set: function (key, data) {
                        sessionStorage.setItem(key, data);
                    },
                },
                load: function (obj) {
                    var slf = this;                    
                    $.ajax({
                        url: obj.url,
                        type: 'GET',
                        datatype: 'json',
                        success: function (data) {
                            slf.cache.set(obj.key, JSON.stringify(data));
                            obj.callback({ Menu: data });
                            if ($('body').hasClass('nav-md')
                                && slf.cache.get('isMenuMinimized')) {
                                $('#menu_toggle').trigger('click');
                            }
                        }
                    });
                },
                navigate: function (url) {
                    appInsights.trackPageView(url);
                    appInsights.setAuthenticatedUserContext(seal.user.userName);
                    Ajax.Request({
                        url: url,
                        success: function (response) {
                            $('#contentarea').html(response);
                            seal.common.afterinit();
                        }
                    });

                },
                parse: function (mn) {
                    var menu = mn.Menu;
                    var amenu = [];
                    var mapper = function (cmenu) {
                        return {
                            Name: cmenu.Name,
                            Url: cmenu.Url
                        };
                    };
                    var parents = menu.filter(function (fmenu) { return parseInt(fmenu.ParentId) === 0; });
                    parents.forEach(function (pmenu) {
                        amenu.push({
                            Description: pmenu.Name,
                            Icon: pmenu.Url,
                            submenus: menu.filter(function (p) {
                                return p.ParentId === pmenu.Id;
                            }).map(function (cmenu) {
                                return {
                                    Name: cmenu.Name,
                                    Url: cmenu.Url,
                                    children: menu.filter(function (p) {
                                        return p.ParentId === cmenu.Id;
                                    }).map(mapper),
                                };
                            }),
                        });
                    });
                    return { Menu: amenu };
                },
                menu: function () {
                    var slf = this;
                    var load = function (mn) {
                        seal.logger.info('loaded');
                        kendo.bind($('#menumodel'), slf.parse(mn));
                        menuactivation();
                    };
                    var items = this.cache.get('menu' + seal.UserId);
                    if (items !== null) { return load({ Menu: JSON.parse(items) }); }
                    else {
                        this.load({
                            url: seal.Url.menu,
                            key: 'menu' + seal.UserId + seal.DepotId,
                            callback: load
                        });
                    }
                }
            },
            helper: function () {
            },
            getPage: function (page) {
                return $(page);
            },
            bind: function (page, omodel) {
                kendo.bind(this.getPage(page), omodel);
            },
            observable: function (model) {
                return kendo.observable(model);
            },
            template: {
                jsondate: function (date) {
                    var regex = null;
                    if (typeof date === 'string') {
                        regex = date.indexOf('Date');
                        if (regex > -1) {
                            return seal.common.StringDateToTimeZone(date.substr(6));
                        }
                        if (seal.common.isoDateRegex
                            && seal.common.isoDateRegex.test(date)) {
                            return new Date(date);
                        }
                    }                    
                    return date;
                },
                date: function (value) {
                    var date = this.jsondate(value);
                    var stringDateTime = kendo.toString(kendo.parseDate(date), seal.format.date);
                    if (stringDateTime === '01/Jan/0001'); {
                        return '';
                    }
                    return stringDateTime;
                },
                datetime: function (value) {
                    var date = this.jsondate(value);                    
                    var stringDateTime = kendo.toString(kendo.parseDate(date), seal.format.datetime);
                    if (stringDateTime === "01/Jan/0001 00:00:00"); {
                        return '';
                    }
                    return stringDateTime;
                }
            },
            extensions: function () {
                kendo.data.binders.dateText = kendo.data.Binder.extend({
                    init: function (element, bindings, options) {
                        //call the base constructor
                        kendo.data.Binder.fn.init.call(this, element, bindings, options);

                        var that = this;
                        //listen for the change event of the element
                        $(that.element).on("change", function () {
                            that.change(); //call the change function
                        });
                    },
                    refresh: function () {
                        var that = this,
                            value = that.bindings["dateText"].get(); //get the value from the View-Model
                        kendo.toString(value, 'MM/dd/yyyy')
                        $(that.element).text(value); //update the HTML input element
                    }
                });
                kendo.data.binders.dateText = kendo.data.Binder.extend({
                    init: function (element, bindings, options) {
                        //call the base constructor
                        kendo.data.Binder.fn.init.call(this, element, bindings, options);

                        var that = this;
                        //listen for the change event of the element
                        $(that.element).on("change", function () {
                            that.change(); //call the change function
                        });
                    },
                    refresh: function () {
                        var that = this,
                            value = that.bindings["dateText"].get(); //get the value from the View-Model
                        kendo.toString(value, 'MM/dd/yyyy')
                        $(that.element).text(value); //update the HTML input element
                    }
                });

                kendo.data.binders.accessvisible = kendo.data.Binder.extend({
                    init: function (widget, bindings, options) {
                        kendo.data.Binder.fn.init.call(this, widget, bindings, options);
                        this.widget = widget;
                    },
                    refresh: function () {
                        var visible = this.bindings.accessvisible.get();
                        var accessKey = this.widget.getAttribute('accesskey');
                        this.widget.style.display = visible ? '' : 'none';
                    }
                });
                kendo.data.binders.accessinvisible = kendo.data.Binder.extend({
                    init: function (widget, bindings, options) {
                        kendo.data.Binder.fn.init.call(this, widget, bindings, options);
                        this.widget = widget;
                    },
                    refresh: function () {
                        var invisible = this.bindings.accessinvisible.get();
                        var accessKey = this.widget.getAttribute('accesskey');
                        this.widget.style.display = invisible ? 'none' : '';
                    }
                });

            },
            validation: {
                CompareExpressions: {
                    LessThan: "<",
                    GreaterThan: ">",
                    LessThanOrEquals: "<=",
                    GreaterThanOrEquals: ">=",
                    Equals: "==",
                    NotEquals: "!="
                },
                Constants: (function () {
                    return {
                        EmptyString: '',
                        Dot: '.',
                        Minus: '-',
                        Zero: '0',
                        MinusZero: '-0',
                        PointZero: '.0',
                        PointRegExp: /\./g,
                        MinusRegExp: /-/g,
                        DotRegExp: /./g,
                        ZeroRegExp: /^-?0{1,}$/,
                        ConsecutiveZeroRegExp: /^-?0{2,}$/,
                        DotWithConsecutiveZeroRegExp: /^\.0{2,}$/,
                        MinusOrDotRegExp: /^-\.?$/,
                        HeaderCategory: 'form1',
                        DefaultCategory: 'Header',
                        MessageTypeClass: {
                            73: 'clsInformation',
                            87: 'clsWarning',
                            69: 'clsException'
                        },
                        MessageType: {
                            Information: 73,
                            Warning: 87,
                            Exception: 69
                        }
                    };
                })(),
                EntityType: {
                    Label: 0,
                    TextBox: 1,
                    ListSingle: 2,
                    ListMulti: 3,
                    Checkbox: 4,
                    Radiobutton: 5,
                    Webcombo: 6,
                    AutoComplete: 7,
                    DateControl: 8,
                    ComboBox: 10
                },
                DataType: {
                    Anything: 0,
                    RejectNegativeandDecimalDot: 1,//integers
                    RejectNegativeButNotDecimalDot: 2,//double >0
                    AcceptNegativeButNotDecimalDot: 3,//whole numbers
                    AcceptNegativeAndDecimalDot: 4,//dobule with minus
                    AcceptLetterAndDigitOnly: 10,//alphanumeric
                    AcceptNamingLetters: 11,//valid naming strings
                    AnythingButNotSpecial: 12,
                    AcceptDate: 20,//dates
                    Email: 30,//valid emails
                    CreditCard: 40,
                    PhycalPath: 50,
                    RelativePath: 51,
                    RegularExpression: 52,
                    Temperature: 5
                },
                Load: (function (s) {
                    var self = this;
                    var name = s.category || self.Category.Default;
                    var category = this.Category.Get(s.category);
                    $.ajax({
                        url: seal.createurl('validation', category.processid, category.groupid),
                        type: 'GET',
                        success: function (result) {
                            $.each(result.Rule, function (i, e) {
                                var rule = self.Json.Decode(e);
                                if (category === undefined) { seal.logger.error('Category not found:' + name); }
                                else { category.rules.push(rule); self.Register(rule); }

                            });
                        }
                    });
                }),
                LoadByCallBack: (function (s, fn) {
                    var self = this;
                    var name = s.category || self.Category.Default;
                    var category = this.Category.Get(s.category);
                    $.ajax({
                        url: seal.createurl('validation', category.processid, category.groupid),
                        type: 'GET',
                        success: function (result) {
                         var res=   fn.apply(self, [result.Rule.map(function (r) {
                                return self.Json.Decode(r);
                            })]);
                            $.each(res, function (i, e) {
                                if (category === undefined) { seal.logger.error('Category not found:' + name); }
                                else { category.rules.push(e); self.Register(e); }
                            });                                                       
                        }
                    });
                }),
                Json: {
                    Decode: (function (r) {
                        r[1] = r[1].replace(/\t/g, '');
                        r[2] = r[2].replace(/\t/g, '');
                        var rule = {
                            Id: r[0],
                            Label: document.getElementById("spn" + r[1]) ? document.getElementById("spn" + r[1]) : { id: "spn" + r[1] },
                            Entity: document.getElementById(r[1]) ? document.getElementById(r[1]) : { id: r[1] },
                            EntityType: r[3],
                            DataType: parseInt(r[4]),
                            MinLength: r[5],
                            MaxLength: r[6],
                            MinDecimal: r[7],
                            MaxDecimal: r[8],
                            IsUpper: r[9],
                            RegularExpression: r[10],
                            MessageType: r[11],
                            CompareExpression: r[12],
                            CompareEntity: document.getElementById(r[13]) ? document.getElementById(r[13]) : { id: r[13] },
                            MinLengthMessage: r[14],
                            MaxLengthMessage: r[15],
                            MinDecimalMessage: r[16],
                            MaxDecimalMessage: r[17],
                            MinDateMessage: r[18],
                            MaxDateMessage: r[19],
                            IsUpperMessage: r[20],
                            CompareMessage: r[21],
                            Message: r[22]
                        };
                        return rule;
                    })
                },
                Register: (function (r) {
                    this.Refresh(r);
                    this.RequiredFieldValidator(r);
                    this.UpperfieldWorker(r);
                    this.CompareFieldValidator(r);
                    $(r.Entity).bind('keypress', this.EventHandler.OnKeyPress);
                    $(r.Entity).bind('change', this.EventHandler.OnChange);
                    $(r.Entity).bind('paste', this.EventHandler.OnPaste);
                }),
                Refresh: (function (rule) {
                    if (rule && rule.Label) {
                        var entity = rule.Entity.id || rule.Entity;
                        var label = rule.Label.id || rule.Label;
                        rule.Entity = document.getElementById(entity) || rule.Entity;
                        rule.Label = document.getElementById(label) || rule.Label;
                    }
                }),
                RequiredFieldValidator: (function (r) {
                    if (r && r.MinLength === 1 && r.Label && r.Label.innerHTML) {
                        r.Label.innerHTML = r.Label.innerHTML.replace(/\<span(.+)\>/g, '');
                        if (r.Entity.value !== undefined && r.Entity.value.trim() !== '') {
                            r.Label.innerHTML = r.Label.innerHTML.replace(/\<\/label\>/g, '').trim() + '<span>*</span>' + '</label>';
                        }
                        else if (r.Entity.value === undefined || r.Entity.value.trim() === '') {
                            r.Label.innerHTML = r.Label.innerHTML.replace(/\<\/label\>/g, '').trim() + '<span title="' + r.MinLengthMessage + '" class="ValidationSummary" validation_focus="' + r.Entity.id + '">*</span></label>';
                        }
                    }
                    else if (r.CompareExpression) {
                        $(r.Label).attr('data-cmp-val', r.CompareMessage);
                        $(r.Label).addClass('CompareSummary');
                    }
                }),
                CompareFieldValidator: (function (r) {
                    if (r.CompareExpression) {
                        $(r.Label).attr('data-cmp-val', r.CompareMessage);
                        $(r.Label).addClass('CompareSummary');
                        $(r.Entity).addClass('CompareIrregularity');
                    }
                }),
                UpperfieldWorker: (function (r) {
                    if (r.IsUpper) { $(r.Entity).css('text-transform', 'uppercase').change(function () { this.value = this.value.toUpperCase() }); }
                }),
                CompareValidator: (function (r) {
                    if (r.CompareExpression) {
                        switch (r.DataType) {
                            case this.DataType.AcceptDate:
                                var lhsDate = seal.getElement(r.Entity.id);
                                var rhsDate = seal.getElement(r.CompareEntity.id);
                                this.Compare(lhsDate.value(), rhsDate.value(), r.CompareExpression, r.Label, r.CompareMessage);
                                break;
                            case this.DataType.Anything:
                                this.Compare(r.Entity.value, r.CompareEntity.value, r.CompareExpression, r.Label, r.CompareMessage);
                                break;
                        }
                    }
                }),
                Compare: (function (lhs, rhs, op, lbl, msg) {
                    switch (op) {
                        case this.CompareExpressions.LessThan:
                            if (lhs < rhs) {
                                $(lbl).attr('data-cmp-val', '');
                                $(lbl).removeClass('CompareSummary');
                            } else {
                                $(lbl).attr('data-cmp-val', msg);
                                $(lbl).addClass('CompareSummary');
                            }
                            break;
                        case this.CompareExpressions.LessThanOrEquals:
                            if (lhs <= rhs) {
                                $(lbl).attr('data-cmp-val', '');
                                $(lbl).removeClass('CompareSummary');
                            } else {
                                $(lbl).attr('data-cmp-val', msg);
                                $(lbl).addClass('CompareSummary');
                            }
                            break;
                        case this.CompareExpressions.Equals:
                            if (lhs == rhs) {
                                $(lbl).attr('data-cmp-val', '');
                                $(lbl).removeClass('CompareSummary');
                            } else {
                                $(lbl).attr('data-cmp-val', msg);
                                $(lbl).addClass('CompareSummary');
                            }
                            break;
                        case this.CompareExpressions.NotEquals:
                            if (lhs != rhs) {
                                $(lbl).attr('data-cmp-val', '');
                                $(lbl).removeClass('CompareSummary');
                            } else {
                                $(lbl).attr('data-cmp-val', msg);
                                $(lbl).addClass('CompareSummary');
                            }
                            break;
                        case this.CompareExpressions.GreaterThanOrEquals:
                            if (lhs >= rhs) {
                                $(lbl).attr('data-cmp-val', '');
                                $(lbl).removeClass('CompareSummary');
                            } else {
                                $(lbl).attr('data-cmp-val', msg);
                                $(lbl).addClass('CompareSummary');
                            }
                            break;
                        case this.CompareExpressions.GreaterThan:
                            if (lhs > rhs) {
                                $(lbl).attr('data-cmp-val', '');
                                $(lbl).removeClass('CompareSummary');
                            } else {
                                $(lbl).attr('data-cmp-val', msg);
                                $(lbl).addClass('CompareSummary');
                            }
                            break;
                    }
                }),
                DateFormat: (function (d) {
                    var dsplit = d.replace("-", " ");
                    return d = new Date(dsplit);
                }),
                Handler: (function () {
                    return {
                        Add: (function (key, value) {
                            this[key] = value;
                            return this;
                        }),
                        Get: (function (key) {
                            return this[key];
                        })
                    };
                })(),
                Category: (function () {
                    var categories = {};
                    return {
                        Default: 'Header',
                        Add: (function (category, container, processid, groupid) {
                            categories[category] = {
                                name: category,
                                container: container,
                                processid: processid,
                                groupid: groupid,
                                handlers: {},
                                rules: [],
                                addhandle: function (handle, fn, formatter) {
                                    this.handlers[handle] = { method: fn, formatter: formatter };
                                }
                            };
                            return categories[category];
                        }),
                        Get: function (category) {
                            return categories[category];
                        },
                        Remove: function (category) {
                            categories[category].rules = [];
                        }
                    };
                })(),
                GetRuleById: (function (category, entityid) {
                    var category = this.Category.Get(category), rules = [];
                    if (category) { rules = category.rules; }
                    var index = 0;
                    for (; index < rules.length;) {
                        if (rules[index].Entity.id === entityid) { return rules[index]; }
                        index++;
                    }
                    return null;
                }),
                IsValid: (function (s) {
                    var outcome = {};
                    var message = '', category = {};
                    if (typeof (s) === "string") { category = this.Category.Get(s); }
                    else { category = s; }
                    var $container = $('#' + category.container);
                    var irregularity = $container.find('.ValidationSummary');
                    var compareIrregularity = $container.find('.CompareSummary');
                    var comparefields = $container.find('.CompareIrregularity');
                    var self = this;
                    $(comparefields).each(function (index, control) {
                        if (control) {
                            var rule = self.GetRuleById(category.name, control);
                            if (rule !== null) { self.CompareValidator(rule); }
                        }
                    });
                    $.each(compareIrregularity, function (i, e) { message += e.getAttribute("data-cmp-val") + " <br> "; });
                    $.each(irregularity, function (i, e) { message += e.title + " <br> "; });
                    outcome = this.OnSubmit(category, {
                        failed: [],
                        message: message,
                        isValid: message.length == 0
                    });
                    return outcome;
                }),
                OnSubmit: function (category, outcome) {
                    category.rules.forEach(function (rule, index) {
                        var handle = category.handlers[rule.Id];
                        if (handle !== undefined) {
                            if (!handle.method()) {
                                outcome.failed.push(rule.Id);
                                var message = rule.Message;
                                if (handle.formatter) { message = handle.formatter(message); }
                                outcome.message += message + " <br> "
                            }
                        }
                    });
                    //outcome.isValid = outcome.message.length > 0;
                    return outcome;
                },
                EventHandler: (function () {
                    var ruleByTarget = function (target) {
                        var self = seal.validation, category = null;
                        var parent = $(target).closest('[data-category]');
                        if (parent) {
                            category = parent.attr('data-category');
                        }
                        return self.GetRuleById(category, target.id);
                    }
                    var getTextBoxValue = (function (event) {
                        var currentTarget = event.target || window.event.target;


                        var r = ruleByTarget(event.target);
                        if (currentTarget.selectionStart == 0 && currentTarget.selectionEnd == r.MaxLength) {
                            return String.fromCharCode(event.which);
                        } else {
                            return currentTarget.value.slice(0, currentTarget.selectionStart)
                                        + String.fromCharCode(event.which)
                                        + currentTarget.value.slice(currentTarget.selectionStart, currentTarget.value.length);
                        }
                    });
                    return {
                        /// <summary>
                        /// Validates the entity when the key is pressed
                        /// </summary>
                        OnKeyPress: (function (e) {
                            if (!window.event
                                && e.key !== "Spacebar"
                                && e.key !== "MozPrintableKey"
                                && (e.which === 0 || e.which == 8)
                                && e.charCode === 0) { return true; }
                            var v = getTextBoxValue(e);
                            var self = seal.validation, value = getTextBoxValue(e), r = ruleByTarget(e.target);
                            if (r == null) {
                                return true;
                            }
                            switch (r.DataType) {
                                case self.DataType.AcceptNegativeAndDecimalDot:
                                    return value.match(self.GetExpressionByRule(r)) != null;
                                    break;
                                case self.DataType.AcceptNegativeButNotDecimalDot:
                                    if (e.key === self.Constants.Minus && value === '') return true;
                                    else if (e.key === self.Constants.Zero) return false;
                                    return self.GetExpressionByRule(r).test(value);
                                    break;
                                case self.DataType.RejectNegativeandDecimalDot:
                                    return value.match(self.GetExpressionByRule(r)) != null;
                                    break;
                                case self.DataType.RejectNegativeButNotDecimalDot:
                                    return value.match(self.GetExpressionByRule(r)) != null;
                                    break;
                                case self.DataType.AcceptNamingLetters:
                                    return self.GetExpressionByRule(r).test(value);
                                    break;
                                case self.DataType.AcceptLetterAndDigitOnly:
                                    return self.GetExpressionByRule(r).test(value);
                                    break;
                                case self.DataType.RegularExpression:
                                    return self.GetExpressionByRule(r).test(value);
                                    break;
                                case self.DataType.Anything:
                                    return self.GetExpressionByRule(r).test(value);
                                    break;
                                case self.DataType.Temperature:
                                    return value.match(self.GetExpressionByRule(r)) != null;
                                    break;
                            }
                        }),
                        OnChange: (function (e) {
                            var self = seal.validation;
                            var rule = ruleByTarget(e.target);
                            if (rule == null) {
                                return true;
                            }
                            else {
                                self.Refresh(rule);
                                if (rule.EntityType == self.EntityType.Radiobutton) {
                                    rule.Entity.value = e.target.value;
                                }
                                self.RequiredFieldValidator(rule);
                                if (rule.DataType == self.DataType.Email && rule.Entity.value.trim() !== '') {
                                    if (self.GetExpressionByRule(rule).test(rule.Entity.value) == true) {
                                        return true;
                                    }
                                    else {
                                        var id = rule.Entity.id;
                                        seal.EmailAlert(id);
                                    }
                                }
                            }                       

                            //var self = seal.validation;
                            //var rule = ruleByTarget(e.target);
                            //if (rule == null) {
                            //    return true;
                            //}
                            //else {
                            //    self.Refresh(rule);
                            //    if (rule.EntityType = self.EntityType.Radiobutton)
                            //    {
                            //        rule.Entity.value = e.target.value;
                            //    }
                            //    self.RequiredFieldValidator(rule);
                            //    if (rule.DataType == self.DataType.Email && rule.Entity.value.trim() !== '') {
                            //        if(self.GetExpressionByRule(rule).test(rule.Entity.value) == true)
                            //        {
                            //            return true;
                            //        }
                            //        else {
                            //            var id = rule.Entity.id;
                            //            seal.EmailAlert(id);
                            //        }
                            //    }
                            //}
                        }),
                        /// <summary>
                        /// Validates the entity when the value is pasted
                        /// </summary>
                        OnPaste: (function (e) {
                            setTimeout(function () {
                                var self = seal.validation, r = ruleByTarget(e.target);
                                if (r == null) {
                                    //console.log("No Element found for " + e.target.id);
                                }
                                else {
                                    var expression = self.GetExpressionByRule(r);
                                    if (r.DataType === self.DataType.AcceptNegativeAndDecimalDot
                                        || r.DataType === self.DataType.RejectNegativeButNotDecimalDot
                                        || r.DataType === self.DataType.Temperature) {
                                        expression = self.GetExpressionByRule(r).Second;
                                        if (self.Constants.PointRegExp.test(e.target.value)) {
                                            expression = self.GetExpressionByRule(r).First;
                                        }
                                    }
                                    if (!expression.test(r.Entity.value)) {
                                        if (r.Entity.value.length > r.MaxLength) {
                                            r.Entity.value = r.Entity.value.substr(0, r.MaxLength);
                                        }
                                        self.RequiredFieldValidator(r);
                                    }
                                }
                            }, 0);
                        }),
                    };
                })(),
                GetExpressionByRule: (function (r) {
                    var expression = null;
                    switch (r.DataType) {
                        case this.DataType.AcceptLetterAndDigitOnly:
                            if (r.MinLength >= 0 && r.MaxLength > 0)
                                expression = new RegExp('^\\w{' + r.MinLength + ',' + r.MaxLength + '}$');
                            else if (r.MinLength > 0 && r.MaxLength == 0)
                                expression = new RegExp('^\\w{' + r.MinLength + ',}$');
                            else expression = new RegExp('^\\w+$');
                            return expression;
                            break;
                        case this.DataType.AcceptNamingLetters:
                            if (r.MinLength > 0 && r.MaxLength > 0)
                                expression = new RegExp('^[a-zA-Z ._]{' + r.MinLength + ',' + r.MaxLength + '}$');
                            else if (r.MinLength == 0 && r.MaxLength > 0)
                                expression = new RegExp('^[a-zA-Z ._]{1,' + r.MaxLength + '}$');
                            else expression = new RegExp('^[a-zA-Z ._]+$');
                            return expression;
                            break;
                        case this.DataType.AcceptNegativeAndDecimalDot:
                            if (r.MinLength == 0 && r.MaxLength > 0)
                                expression = new RegExp('^-?(\\d{1,' + r.MaxLength + '})?(\\.?|(\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                            if (r.MinLength > 0 && r.MaxLength == 0 && r.MinDecimal == 0 && r.MaxDecimal == 0)
                                expression = new RegExp('^-?\\d+$');
                            if (r.MinLength > 0 && r.MaxLength == 0 && r.MinDecimal > 0 && r.MaxDecimal > 0)
                                expression = new RegExp('^-?(\\d+)?(\\.?|\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                            expression = RegExp('^-?(\\d{' + r.MinLength + ',' + r.MaxLength + '})?(\\.?|(\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                            return expression;
                            break;
                        case this.DataType.AcceptNegativeButNotDecimalDot:
                            if (r.MinLength > 0 && r.MaxLength > 0)
                                expression = new RegExp('^-?\\d{' + r.MinLength + ',' + r.MaxLength + '}$');
                            else if (r.MinLength == 0 && r.MaxLength > 0)
                                expression = new RegExp('^-?\\d{1,' + r.MaxLength + '}$');
                            else expression = new RegExp('^-?\\d+$');
                            return expression;
                            break;
                        case this.DataType.Email:
                            expression = /^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_.-])+\.([a-zA-Z])+([a-zA-Z])+$/;
                            return expression;
                            break;
                        case this.DataType.RejectNegativeandDecimalDot:
                            if (r.MinLength > 0 && r.MaxLength > 0)
                                expression = new RegExp('^\\d{' + r.MinLength + ',' + r.MaxLength + '}$');
                            else if (r.MinLength == 0 && r.MaxLength > 0)
                                expression = new RegExp('^\\d{1,' + r.MaxLength + '}$');
                            else expression = new RegExp('^\\d+$');
                            return expression;
                            break;
                        case this.DataType.RejectNegativeButNotDecimalDot:
                            if (r.MinLength == 0 && r.MaxLength > 0)
                                expression = new RegExp('^(\\d{1,' + r.MaxLength + '})?(\\.?|(\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                            if (r.MinLength > 0 && r.MaxLength == 0 && r.MinDecimal == 0 && r.MaxDecimal == 0)
                                expression = new RegExp('^\\d+$');
                            if (r.MinLength > 0 && r.MaxLength == 0 && r.MinDecimal > 0 && r.MaxDecimal > 0)
                                expression = new RegExp('^(\\d+)?(\\.?|(\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                            expression = RegExp('^(\\d{' + r.MinLength + ',' + r.MaxLength + '})?(\\.?|(\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                            return expression;
                            break;
                        case this.DataType.AnythingButNotSpecial:
                            return new RegExp(/^([a-zA-Z0-9_\s\-]*)$/);
                            break;
                        case this.DataType.RegularExpression:
                            return new RegExp(r.RegularExpression);
                            break;
                        case this.DataType.Anything:
                            if (r.MinLength > 0 && r.MaxLength > 0)
                                expression = new RegExp('^[\\S\\s]{' + r.MinLength + ',' + r.MaxLength + '}$');
                            else if (r.MinLength == 0 && r.MaxLength > 0)
                                expression = new RegExp('^[\\S\\s]{1,' + r.MaxLength + '}$');
                            else expression = new RegExp('^[\\S\\s]*$');
                            return expression;
                            break;
                        case this.DataType.Temperature:
                            if (r.MinLength == 0 && r.MaxLength > 0)
                                expression = new RegExp('^-?(\\d{1,' + r.MaxLength + '})?(\\.?|(\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                            if (r.MinLength > 0 && r.MaxLength == 0 && r.MinDecimal == 0 && r.MaxDecimal == 0)
                                expression = new RegExp('^-?\\d+$');
                            if (r.MinLength > 0 && r.MaxLength == 0 && r.MinDecimal > 0 && r.MaxDecimal > 0)
                                expression = new RegExp('^-?(\\d+)?(\\.?|\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                            expression = RegExp('^-?(\\d{' + r.MinLength + ',' + r.MaxLength + '})?(\\.?|(\\.\\d{' + r.MinDecimal + ',' + r.MaxDecimal + '})?)$');
                            return expression;
                            break;
                    }
                    return expression;
                }),
            },
            EmailAlert: function (id) {
                let controlId = id;
                let Label = document.getElementById('spn' + id);
                if (Label.innerText.includes("*")) {
                    Label.innerHTML = Label.innerHTML.replace(/\<span(.+)\>/g, '');
                    Label.innerHTML = Label.innerHTML.replace(/\<\/label\>/g, '').trim() + '<span title="Invalid EmailId" class="ValidationSummary" validation_focus="' + id + '">*</span></label>';
                }
                else {
                    seal.common.ShowMessage("Invalid Email Id", "Email Validation", [{ text: seal.common.constants.btnOk, action: "seal.EmailOK(" + controlId + ")" }]);
                }
            },
            EmailOK: function (control) {
                $("#" + control.id).focus();
                control.value = "";
                seal.common.close();
            },
            combobox: {

                valueMapper: function (options) {
                    options.success([]);
                },
                onFiltering: function (e) {
                    e.preventDefault();
                    if (e.filter.value !== undefined
                        && e.filter.value.length > 3) {
                        e.sender.dataSource.read({
                            filter: e.filter.value
                        });
                    }
                },
                onNolimitFiltering: function (e) {
                    e.preventDefault();
                    if (e.filter.value !== undefined
                        && e.filter.value.length > 0) {
                        e.sender.dataSource.read({
                            filter: e.filter.value
                        });
                    }
                }
            },
            DateToString: function (v) {
                return kendo.toString(v, "yyyy-MM-dd");
            },
            grid: {
                refresh: function (name) {
                    var grid = $("#" + name).data("kendoGrid");
                    grid.dataSource.read();
                }
            },
            filter: {
                applyFilter: function (e, gridName) {
                    if (e) {
                        e.preventDefault();
                    }
                    var grid = $("#" + gridName).data("kendoGrid");
                    grid.dataSource.page(1);
                },
                showFilter: function (e) {
                    var text = $.trim(e.currentTarget.innerText);
                    if (text === 'Show Filter') {
                        e.currentTarget.innerHTML = "<i class='fa fa-angle-double-up' aria-hidden='true'></i>&nbsp; Hide Filter";
                    } else {
                        e.currentTarget.innerHTML = "<i class='fa fa-angle-double-down' aria-hidden='true'></i>&nbsp; Show Filter";
                    }
                },
            },
            customSource: function (obj) {
                return new kendo.data.DataSource({
                    pageSize: 10,
                    page: 1,
                    total: 0,
                    serverPaging: true,
                    serverSorting: true,
                    serverGrouping: true,
                    serverAggregates: true,
                    filter: [],
                    schema: {
                        data: "Data",
                        total: "Total",
                    },
                    transport: {
                        read: {
                            url: obj.url,
                            type: "GET",
                            dataType: "json",
                        },
                        parameterMap: function (options, operation) {
                            if (operation == "read" && options) {
                                isDescending = false;
                                member = "";
                                if (options.sort != null && options.sort.length > 0) {
                                    isDescending = options.sort[0].dir == "asc" ? false : true;
                                    member = options.sort[0].field;
                                }
                                var model = obj.params();
                                model.page = options.page;
                                model.pageSize = options.pageSize;
                                model.isDescending = isDescending;
                                model.member = member;
                                return JSON.parse(JSON.stringify(model));
                            }
                        },
                    }
                });
            },
            source: function (obj) {
                return new kendo.data.DataSource({
                    pageable: false,
                    serverPaging: false,
                    serverFiltering: false,
                    transport: {
                        read: {
                            url: obj.url,
                            type: "GET",
                            dataType: "json",
                            data: obj.data || function () {
                                return {
                                    search: ''
                                };
                            },
                        },
                    },
                    schema: {
                        total: "Total", // total is returned in the "total" field of the response ,
                        data: "Data"
                    }
                });
            },
            nopageingsource: function (obj) {
                return new kendo.data.DataSource({
                    pageSize: 1000 ,
                    pageable: false,
                    serverPaging: false,
                    serverFiltering: false,
                    transport: {
                        read: {
                            url: obj.url,
                            type: "GET",
                            dataType: "json",
                            data: obj.data || function () {
                                return {
                                    search: ''
                                };
                            },
                        },
                    },
                    schema: {
                        total: "Total", // total is returned in the "total" field of the response ,
                        data: "Data"
                    }
                });
            },
            virtualSource: function (obj) {
                //debugger;
                return new kendo.data.DataSource({
                    pageSize: obj.pageSize || 31,
                    transport: {
                        read: {
                            url: obj.url,
                            type: "GET",
                            dataType: "json",
                            data: obj.data || function () {
                                return {
                                    search: ''
                                };
                            },
                        },
                    },
                    schema: {
                        data: "Data",
                        total: "Total",
                    },
                    error: function (request) {
                        seal.common.clienterror(request, "");
                    },
                    serverPaging: true,
                    serverFiltering: true
                })
            },

            virtualSourceWithFilter: function (obj) {
                var self = this;
                return new kendo.data.DataSource({
                    pageSize: obj.pageSize || 31,
                    transport: {
                        read: {
                            url: obj.url,
                            type: "GET",
                            dataType: "json",
                            data: obj.data || function (args) {
                                return {
                                    filter: obj.filterText
                                };
                            },
                        },
                    },
                    schema: {
                        data: "Data",
                        total: "Total",
                    },
                    error: function (request) {
                        seal.common.clienterror(request, "");
                    },
                    serverPaging: true,
                    serverFiltering: true
                })
            },
        }
    }();
}

