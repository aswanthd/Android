﻿seal['useraccesscreate'] = {
    init: function (arg) {
        this.url = arg.url;
        this.constant = arg.constant;
        this.msg = arg.msg;
        this.omodel = this.updateModel(arg.model);
        this.messages = JSON.parse(arg.resources);
        seal.admin.handleGrants("#UserManagementEntry");
        this.bindModel();

        if (this.omodel.Id > 0 && this.omodel.UsageType != null && this.omodel.UsageType.Code != "") {
            this.loadValidation(this.omodel.UsageType.Code);
        }
        else {
            this.loadValidation();
        }

        this.loadDepotValidation();
        this.loadGrantValidation();
        if (seal.useraccesscreate.omodel.Id > 0 && seal.useraccesscreate.omodel.Status.Code == "A") {
            seal.useraccesscreate.omodel.set("isdeletevisible", true);
            seal.useraccesscreate.usageTypeChange();
            seal.useraccesscreate.onUserOrganizationChange();
        }
    },

    loadValidation: function () {
        var VH = seal.validation;
        var category = seal.validation.Category.Add('EditUserDetail', 'divCreateuserdetail', 'DSA00010', 78);
        VH.Load({ category: 'EditUserDetail' });
    },

    loadValidation: function (code) {
        var vh = seal.validation;
        var category = seal.validation.Category.Add("EditUserDetail", "divCreateuserdetail", "DSA00010", 78);
        if (code == "D") {
            index = 0;
            vh.LoadByCallBack({ category: "EditUserDetail" }, function (rules) {
                $.each(rules, function (i, d) {
                    if (d.Label.id == "spnuserOrganization") {
                        index = i;
                    }
                });
                rules.splice(index, 1);
                return rules;
            });
        }
        else {
            vh.Load({ category: 'EditUserDetail' });
        }
    },

    page: '#UserManagementEntry',
    grid: '#DepotDetailsTariffGrid',
    url: {},
    constant: {},
    messages: {},
    msg: {},
    omodel: {},
    source: function (obj) {
        return new kendo.data.DataSource({
            pageSize: obj.pageSize || 30,
            pageable: true,
            serverPaging: true,
            serverFiltering: false,
            transport: {
                read: {
                    url: obj.url,
                    type: "GET",
                    dataType: "json",
                    data: obj.data || function () {
                        return {
                            search: ''
                        };
                    },
                },
            },
            schema: {
                total: "Total",
                data: "Data"
            },
            error: function (request) {
                seal.common.clienterror(request, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER);
            },
        });
    },
    vsource: function (obj) {
        return new kendo.data.DataSource({
            pageSize: obj.pageSize,
            pageable: false,
            serverPaging: false,
            serverFiltering: false,
            schema: {
                data: "Data",
                total: "Total",
            },
            transport: {
                read: {
                    url: obj.url,
                    type: "GET",
                    dataType: "json",
                    data: obj.data || function () {
                        return {
                            search: ''
                        };
                    },
                },
            },
            error: function (request) {
                seal.common.clienterror(request, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER);
            },
        });
    },
    updateModel: function (model) {
        var currentItem = this;
        model = seal.common.DecodeJsonObject(model);
        model.Statuses = currentItem.source({ url: currentItem.url.searchGeneralCodes + '?reference=' + currentItem.constant.STATUSCODE });
        model.searchdepartments = currentItem.source({ url: currentItem.url.searchGeneralCodes + '?reference=' + currentItem.constant.DEPARTMENTCODE });
        model.SearchRegions = currentItem.source({ url: currentItem.url.searchRegionNames });
        model.SearchModuleName = currentItem.source({ url: currentItem.url.SearchModuleName });
        model.SearchRights = currentItem.source({ url: currentItem.url.SearchRights });
        model.usageTypes = currentItem.source({ url: currentItem.url.searchGeneralCodes + '?reference=' + currentItem.constant.USAGETYPE });
        model.organizations = [];
        model.IsVisibleDepotGrid = true;
        model.IsVisibleDepotEntry = false;
        model.IsDepotAddVisible = true;
        model.IsDepotUpdateVisible = false;
        model.AccessRightsGridClick = currentItem.AccessRightsGridClick;
        model.IsVisibleAccessDetailsGrid = true;
        model.IsVisibleAccessRightsEntry = false;
        model.IsAccessRightsUpdateVisible = false;
        model.SelectedProgramId = 0;
        model.cpyAccessDetails = model.AccessDetails;
        model.addNewDepotDetails = currentItem.addNewDepotDetails;
        model.confirmcancel = currentItem.confirmcancel;
        model.depotentrycancel = currentItem.depotentrycancel;
        model.addDepotDetails = currentItem.addDepotDetails;
        model.cpyDepotDetails = model.DepotDetails;
        model.addNewAccessDetails = currentItem.addNewAccessDetails;
        model.addAccessRightsDetails = currentItem.addAccessRightsDetails;
        model.AccessRightsentrycancel = currentItem.AccessRightsentrycancel;
        model.newDepotItemId = 0;
        model.newAccessItemId = 0;
        if (model.AccessDetails.length > 0) {
            model.newAccessItemId = model.AccessDetails.length;
        }
        model.isdeletevisible = false;
        model.confirmdelete = currentItem.confirmdelete;
        model.copyuserRights = currentItem.copyuserRights;
        model.searchusers = currentItem.source({ url: currentItem.url.SearchUserInfo });
        model.cpyAccessDetail = model.AccessDetail;
        model.EmailIdOk = currentItem.EmailIdOk;
        model.SearchPrograms = [];
        model.DepotGridClick = currentItem.DepotGridClick;
        model.confirmdepotdelete = currentItem.depotdelete;
        model.depotupdate = currentItem.depotupdate;
        model.CurrentRowDepotIndex = 0;
        model.CurrentRowAccessIndex = 0;
        model.CurrentFeaturIndex = 0;
        model.featuregridClick = currentItem.featuregridClick;
        model.confirmSave = currentItem.confirmSave;
        model.ShowAccessRigths = currentItem.ShowAccessRigths;
        model.RightsChange = currentItem.RightsChange;
        model.confirmAccessRightsdelete = currentItem.confirmAccessRightsdelete;
        model.onRegionChange = currentItem.onRegionChange;
        model.onModuleChange = currentItem.onModuleChange;
        model.IsFullModuleAccess = false;
        model.refreshProp = currentItem.refreshProp;
        model.fullmoduleaccesschange = currentItem.fullmoduleaccesschange;
        model.onDepotChange = currentItem.onDepotChange; //Confirm with Anbu
        model.usageTypeChange = currentItem.usageTypeChange;
        model.onUserOrganizationChange = currentItem.onUserOrganizationChange;
        model.onUsageTypeChange = currentItem.onUsageTypeChange;
        model.orgEnable = true;
        model.IsAccessRightsAddVisible = true;
        model.IsUsageTypeAdded = false;
        model.IsDepotEnabled = true;
        model.onDepotNameChange = currentItem.onDepotNameChange;
        model.bckupDepotDetail = model.DepotDetail;
        return seal.observable(model);
    },
    onDepotNameChange: function () {
        $("#RegionName").trigger("change");
        if (typeof (seal.useraccesscreate.omodel.DepotDetail) === 'string' || seal.useraccesscreate.omodel.DepotDetail==null) {
            seal.useraccesscreate.omodel.set('DepotDetail', seal.useraccesscreate.omodel.bckupDepotDetail);
        }
    },
    usageTypeChange: function () {
        var spanUserOrganization = $('#spnuserOrganization span');
        var spnDepot = $('#spnDepot span');
        me = seal.useraccesscreate;
        me.omodel.set("IsUsageTypeAdded", true);
        if (me.omodel.UsageType.Code == "D") {
            me.omodel.set("organizations", []);
            me.omodel.set("orgEnable", false);
            me.omodel.set("UserOrganization", { Id: "", Name: "" });
            spanUserOrganization.removeClass('ValidationSummary');
            me.omodel.set("IsDepotEnabled", true);
        }
        else if (me.omodel.UsageType.Code == "R" || me.omodel.UsageType.Code == "H" || me.omodel.UsageType.Code == "A") {
            var msg = seal.useraccesscreate.messages.DSUAM_15;
            Label = document.getElementById('spnuserOrganization');
            Label.innerHTML = Label.innerHTML.replace(/\<span(.+)\>/g, '');
            Label.innerHTML = Label.innerHTML.replace(/\<\/label\>/g, '').trim() + '<span title="' + msg + '">*</span>' + '</label>';
            if (me.omodel.UserOrganization.Name == "") {
                spanUserOrganization.addClass('ValidationSummary');
            }
            path = me.url.businessPartner + "?role=" + me.omodel.UsageType.Code;
            me.omodel.set("organizations", me.source({ url: path }));
            me.omodel.set("orgEnable", true);
            spnDepot.removeClass('ValidationSummary');
            me.omodel.set("IsDepotEnabled", false);
        }
    },

    onUsageTypeChange: function () {        
        var spanUserOrganization = $('#spnuserOrganization span');
        var spnDepot = $('#spnDepot span');
        me = seal.useraccesscreate;
        me.omodel.set("IsUsageTypeAdded", true);
        if (me.omodel.UsageType.Code == "D") {
            me.omodel.set("organizations", []);
            me.omodel.set("orgEnable", false);
            me.omodel.set("UserOrganization", { Id: "", Name: "" });
            spanUserOrganization.removeClass('ValidationSummary');
            me.omodel.set("IsDepotEnabled", true);
        }
        else if (me.omodel.UsageType.Code == "R" || me.omodel.UsageType.Code == "H" || me.omodel.UsageType.Code == "A") {
            //seal.useraccesscreate.loadValidation();           
            me.omodel.set("UserOrganization", { Id: "", Name: "" });
            var msg = seal.useraccesscreate.messages.DSUAM_15;
            Label = document.getElementById('spnuserOrganization');
            //Label.innerHTML = Label.innerHTML.replace(/\<span(.+)\>/g, '');
            //Label.innerHTML = Label.innerHTML.replace(/\<\/label\>/g, '').trim() + '<span title="' + msg + '">*</span>' + '</label>';
            if (me.omodel.UserOrganization.Name == "") {
                spanUserOrganization.addClass('ValidationSummary');
            }
            path = me.url.businessPartner + "?role=" + me.omodel.UsageType.Code;
            me.omodel.set("organizations", me.source({ url: path }));
            me.omodel.set("orgEnable", true);
            spnDepot.removeClass('ValidationSummary');
            me.omodel.set("IsDepotEnabled", false);           
        }
        else {
            spnDepot.addClass('ValidationSummary');
            me.omodel.set("IsDepotEnabled", true);
        }
        me = seal.useraccesscreate;
        if (me.omodel.UsageType.Code != "D" && me.omodel.UserOrganization.Name == "") {
            spanUserOrganization.addClass('ValidationSummary');
        }
        else {
            spanUserOrganization.removeClass('ValidationSummary');
        }
    },

    onUserOrganizationChange: function () {
        var spanUserOrganization = $('#spnuserOrganization span');
        me = seal.useraccesscreate;
        if (me.omodel.UsageType.Code != "D" && me.omodel.UserOrganization.Name == "") {
            spanUserOrganization.addClass('ValidationSummary');
        }
        else {
            spanUserOrganization.removeClass('ValidationSummary');
        }
    },

    confirmdelete: function () {
        var cmodel = seal.useraccesscreate.omodel;
        Ajax.Request({
            url: seal.useraccesscreate.url.deactivateuser,
            type: "POST",
            data: {
                Id: cmodel.Id,
            },
            cache: false,
            success: function (data) {
                if (data.success) {
                    seal.common.ShowMessage(data.message, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER, [{ text: seal.common.constants.btnOk, action: "seal.useraccesscreate.cancel()" }]);
                }
                else {
                    seal.common.ShowMessage(data.message, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER);
                }
            },
            error: function (data) {
                seal.common.ShowMessage(data.message, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER);
            }
        });
    },
    onDepotChange: function () {
        seal.useraccesscreate.omodel.set("AccessDetail.Module", '');
        seal.useraccesscreate.omodel.set("AccessDetail.Menu", '');
    },
    onModuleChange: function () {
        seal.useraccesscreate.omodel.set("SearchPrograms", seal.useraccesscreate.vsource({ url: seal.useraccesscreate.url.SearchProgramName + '?parentId=' + seal.useraccesscreate.omodel.AccessDetail.Module.Id + '&usageType=' + seal.useraccesscreate.omodel.UsageType.Code }));
    },
    onRegionChange: function () {
        seal.useraccesscreate.omodel.set("SearchDepotName", seal.useraccesscreate.source({ url: seal.useraccesscreate.url.searchDepotNames + '?regionId=' + seal.useraccesscreate.omodel.DepotDetail.Region.Id }));
    },
    EmailIdOk: function () {
        if (seal.useraccesscreate.omodel.EmailId != "") {
            Ajax.Request({
                url: seal.useraccesscreate.url.edit + "?id=" + seal.useraccesscreate.omodel.EmailId,
                type: "GET",
                cache: false,
                success: function (data) {
                    seal.useraccesscreate.omodel.set("DepotDetails", data.DepotDetails);
                    seal.useraccesscreate.omodel.set("AccessDetails", data.AccessDetails);
                    seal.useraccesscreate.omodel.set("cpyDepotDetails", data.DepotDetails);
                    seal.useraccesscreate.omodel.set("cpyAccessDetails", data.AccessDetails);
                    $('#copyrightsPopUp').modal('hide');
                },
                error: function (data) {
                    seal.common.ShowMessage(data.message, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER, [{ text: seal.common.constants.btnOk, action: "seal.useraccesscreate.cancel()" }]);
                }
            });
        }
        else {
            seal.common.ShowMessage(seal.useraccesscreate.messages.MSG_ENTEREMAILID, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER);
        }

    },

    copyuserRights: function () {
        $("#cpyuserright").trigger('click');
    },

    confirmAccessRightsdelete: function () {
        var rowIndex = seal.useraccesscreate.omodel.CurrentRowAccessIndex;
        UserAccess = seal.useraccesscreate.omodel.cpyAccessDetails[rowIndex];
        seal.useraccesscreate.omodel.cpyAccessDetails.splice(rowIndex, 1);
        $.each(seal.useraccesscreate.omodel.AccessDetails, function (index, value) {
            if (value.Id == UserAccess.Id) {
                if (seal.useraccesscreate.omodel.AccessDetails[index].RecordRowStatus == seal.common.recordRowStatus.Added) {
                    seal.useraccesscreate.omodel.AccessDetails.splice(index, 1);
                }
                else {
                    seal.useraccesscreate.omodel.AccessDetails[index].RecordRowStatus = seal.common.recordRowStatus.Deleted;
                }
                return false;
            }
        });

        seal.useraccesscreate.AccessRightsentrycancel();
    },
    checkProgrameHasFeatur: function () {
        hasFeature = true;
        $.each(seal.useraccesscreate.omodel.AccessDetails, function (index, item) {
            if (item.Features.length == 0) {
                hasFeature = false;
            }
        });
        return hasFeature;
    },
    featuregridClick: function () {
        var grid = $("#featuregrid").data("kendoGrid");
        var rowIndex = grid.select().closest("tr").index();
        rowItem = seal.useraccesscreate.omodel.Features[rowIndex];
        seal.useraccesscreate.omodel.set("CurrentFeaturIndex", rowIndex);
        Ajax.Request({
            url: seal.useraccesscreate.url.GetRights,
            type: "POST",
            data: { processId: seal.useraccesscreate.omodel.SelectedProgramId, featureId: rowItem.Id },
            cache: false,
            success: function (data) {
                rights = [];
                $.each(data, function (index, row) {
                    rights.push(row.Rights);
                });
                seal.useraccesscreate.omodel.set("RightLists", rights);
                seal.useraccesscreate.omodel.set("Feature", rowItem);
            },
            error: function (data) {
                seal.common.ShowMessage(data.message, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER, [{ text: seal.common.constants.btnOk, action: "seal.useraccesscreate.cancel()" }]);
            }
        });
    },

    AccessRightsGridClick: function (e) {
        var grid = $("#AccessRightsGrid").data("kendoGrid");
        var rowIndex = grid.select().closest("tr").index();
        UserAccessList = seal.useraccesscreate.omodel.cpyAccessDetails[rowIndex];
        seal.useraccesscreate.omodel.set("AccessDetail", UserAccessList);
        seal.useraccesscreate.omodel.set("CurrentRowAccessIndex", rowIndex);
        seal.useraccesscreate.omodel.set("IsAccessRightsAddVisible", false);
        seal.useraccesscreate.omodel.set("IsAccessRightsUpdateVisible", true);
        seal.useraccesscreate.omodel.set("IsVisibleAccessDetailsGrid", false);
        seal.useraccesscreate.omodel.set("IsVisibleAccessRightsEntry", true);
        seal.useraccesscreate.omodel.set("isEntry", false);
        $("#Module").trigger("change");
        $("#Program").trigger("change");
        $("#Depot").trigger("change");
    },

    depotupdate: function (e) {
        UserAccessMangement =
        {
            Id: seal.useraccesscreate.omodel.DepotDetail.Id,
            Region: { Id: seal.useraccesscreate.omodel.DepotDetail.Region.Id, Name: seal.useraccesscreate.omodel.DepotDetail.Region.Name },
            Depot: { Id: seal.useraccesscreate.omodel.DepotDetail.Depot.Id, Name: seal.useraccesscreate.omodel.DepotDetail.Depot.Name },
        };

        $.each(seal.useraccesscreate.omodel.DepotDetails, function (index, value) {
            if (value.Id == UserAccessMangement.Id) {
                seal.useraccesscreate.omodel.DepotDetails[index].set("Id", UserAccessMangement.Id);
                seal.useraccesscreate.omodel.DepotDetails[index].set("Region", UserAccessMangement.Region);
                seal.useraccesscreate.omodel.DepotDetails[index].set("Depot", UserAccessMangement.Depot);


                if (seal.useraccesscreate.omodel.DepotDetails[index].RecordRowStatus != seal.common.recordRowStatus.Added) {
                    seal.useraccesscreate.omodel.DepotDetails[index].RecordRowStatus = seal.common.recordRowStatus.Modified;
                }
            }
        });

        index = seal.useraccesscreate.omodel.CurrentRowDepotIndex;
        seal.useraccesscreate.omodel.cpyDepotDetails[index].set("Id", UserAccessMangement.Id);
        seal.useraccesscreate.omodel.cpyDepotDetails[index].set("Region", UserAccessMangement.Region);
        seal.useraccesscreate.omodel.cpyDepotDetails[index].set("Depot", UserAccessMangement.Depot);

        if (seal.useraccesscreate.omodel.cpyDepotDetails[index].RecordRowStatus != seal.common.recordRowStatus.Added) {
            seal.useraccesscreate.omodel.cpyDepotDetails[index].RecordRowStatus = seal.common.recordRowStatus.Modified;
        }

        seal.useraccesscreate.clearDepotDetailsEntry();

    },

    DepotGridClick: function (e) {
        var grid = $("#DepotDetailsTariffGrid").data("kendoGrid");
        var rowIndex = grid.select().closest("tr").index();
        UserAccessList = seal.useraccesscreate.omodel.DepotDetails[rowIndex];
        seal.useraccesscreate.omodel.set("DepotDetail", UserAccessList);
        seal.useraccesscreate.omodel.onRegionChange();
        seal.useraccesscreate.omodel.set("CurrentRowDepotIndex", rowIndex);
        seal.useraccesscreate.omodel.set("IsDepotAddVisible", false);
        seal.useraccesscreate.omodel.set("IsDepotUpdateVisible", true);
        seal.useraccesscreate.omodel.set("IsVisibleDepotGrid", false);
        seal.useraccesscreate.omodel.set("IsVisibleDepotEntry", true);

    },

    depotdelete: function () {
        var rowIndex = seal.useraccesscreate.omodel.CurrentRowDepotIndex;
        UserAccess = seal.useraccesscreate.omodel.cpyDepotDetails[rowIndex];
        seal.useraccesscreate.omodel.cpyDepotDetails.splice(rowIndex, 1);
        $.each(seal.useraccesscreate.omodel.DepotDetails, function (index, value) {
            if (value.Id == UserAccess.Id) {
                if (seal.useraccesscreate.omodel.DepotDetails[index].RecordRowStatus == seal.common.recordRowStatus.Added) {
                    seal.useraccesscreate.omodel.DepotDetails.splice(index, 1);
                }
                else {
                    seal.useraccesscreate.omodel.DepotDetails[index].RecordRowStatus = seal.common.recordRowStatus.Deleted;
                }
            }
        });

        seal.useraccesscreate.clearDepotDetailsEntry();
    },

    addNewDepotDetails: function (e) {
        seal.useraccesscreate.omodel.set("IsVisibleDepotGrid", false);
        seal.useraccesscreate.omodel.set("IsVisibleDepotEntry", true);
        seal.useraccesscreate.clearDepot();
        $("#RegionName").trigger("change");
        $("#DepotName").trigger("change");
    },

    addNewAccessDetails: function (e) {
        me = seal.useraccesscreate;
        seal.useraccesscreate.omodel.set("IsVisibleAccessDetailsGrid", false);
        seal.useraccesscreate.omodel.set("IsVisibleAccessRightsEntry", true);
        seal.useraccesscreate.omodel.AccessDetail.set("IsFullModuleAccess", false);
        seal.useraccesscreate.omodel.set("isEntry", true);
        $("#Depot").trigger("change");
        $("#Module").trigger("change");
        $("#Program").trigger("change");
        if (me.omodel.UsageType.Code == "D") {
            $('#spnDepot span').addClass('ValidationSummary');
            me.omodel.set("IsDepotEnabled", true);
        }
        else if (me.omodel.UsageType.Code == "R" || me.omodel.UsageType.Code == "H" || me.omodel.UsageType.Code == "A") {
            $('#spnDepot span').removeClass('ValidationSummary');
            me.omodel.set("IsDepotEnabled", false);
        }
    },
    depotentrycancel: function (e) {
        seal.useraccesscreate.omodel.set("IsDepotAddVisible", true);
        seal.useraccesscreate.omodel.set("IsDepotUpdateVisible", false);
        seal.useraccesscreate.omodel.set("IsVisibleDepotGrid", true);
        seal.useraccesscreate.omodel.set("IsVisibleDepotEntry", false);
        seal.useraccesscreate.clearDepotDetailsEntry();
    },
    AccessRightsentrycancel: function (e) {
        seal.useraccesscreate.omodel.set("IsAccessRightsAddVisible", true);
        seal.useraccesscreate.omodel.set("IsAccessRightsUpdateVisible", false);
        seal.useraccesscreate.omodel.set("IsVisibleAccessDetailsGrid", true);
        seal.useraccesscreate.omodel.set("IsVisibleAccessRightsEntry", false);
        seal.useraccesscreate.clearAccessDetailEntry();
    },
    addDepotDetails: function (e) {
        var outCome = seal.validation.IsValid('EditDepotDetail');
        if (outCome.isValid) {
            seal.useraccesscreate.omodel.newDepotItemId = seal.useraccesscreate.omodel.newDepotItemId + 1;
            UserAccessDepot =
                {
                    Id: seal.useraccesscreate.omodel.newDepotItemId,
                    Region: { Name: seal.useraccesscreate.omodel.DepotDetail.Region.Name, Id: seal.useraccesscreate.omodel.DepotDetail.Region.Id },
                    Depot: { Name: seal.useraccesscreate.omodel.DepotDetail.Depot.Name, Id: seal.useraccesscreate.omodel.DepotDetail.Depot.Id },
                    MSCOwn: { Code: seal.useraccesscreate.omodel.DepotDetail.MSCOwn.Code, Description: seal.useraccesscreate.omodel.DepotDetail.MSCOwn.Description },
                    Location: { Name: seal.useraccesscreate.omodel.DepotDetail.Location.Name, Code: seal.useraccesscreate.omodel.DepotDetail.Location.Code },
                    RecordRowStatus: seal.common.recordRowStatus.Added,
                };
            seal.useraccesscreate.omodel.DepotDetails.push(UserAccessDepot);
            seal.useraccesscreate.omodel.cpyDepotDetails.push(UserAccessDepot);
            seal.useraccesscreate.clearDepotDetailsEntry();
        }
        else {
            seal.common.ShowMessage(outCome.message, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER);
        }
    },
    fullmoduleaccesschange: function () {
        var spnProgram = $("#spnProgram span");
        if (seal.useraccesscreate.omodel.IsFullModuleAccess) {
            spnProgram.removeClass("ValidationSummary");
        }
        else {
            spnProgram.addClass("ValidationSummary");
        }
    },
    addAccessRightsDetails: function (e) {
        var outCome = seal.validation.IsValid('EditGrantDetail');
        if (outCome.isValid) {
            URL = "";
            data = {};
            if (seal.useraccesscreate.omodel.IsFullModuleAccess) {
                URL = seal.useraccesscreate.url.getProgramesByModule;
                data = { processId: seal.useraccesscreate.omodel.AccessDetail.Module.Id, usageType: seal.useraccesscreate.omodel.UsageType.Code };
            }
            else {
                URL = seal.useraccesscreate.url.getAccessFeatures;
                data = { userId: 0, depotId: 0, processId: seal.useraccesscreate.omodel.AccessDetail.Menu.Id };
            }
            Ajax.Request({
                url: URL,
                type: "GET",
                data: data,
                cache: false,
                success: function (datalist) {
                    if (seal.useraccesscreate.omodel.IsFullModuleAccess) {
                        $.each(datalist, function (index, item) {
                            seal.useraccesscreate.omodel.newAccessItemId = seal.useraccesscreate.omodel.newAccessItemId + 1;
                            isExist = false;
                            $.each(seal.useraccesscreate.omodel.AccessDetails, function (rowindex, rowitem) {
                                if (rowitem.Menu.Id == item.Menu.Id && rowitem.Depot.Id == seal.useraccesscreate.omodel.AccessDetail.Depot.Id) {
                                    isExist = true;
                                }
                            });
                            if (!isExist) {
                                item.Id = seal.useraccesscreate.omodel.newAccessItemId;
                                item.RecordRowStatus = seal.common.recordRowStatus.Added;
                                item.Module = { Name: seal.useraccesscreate.omodel.AccessDetail.Module.Name, Id: seal.useraccesscreate.omodel.AccessDetail.Module.Id };
                                item.Depot = { Name: seal.useraccesscreate.omodel.AccessDetail.Depot.Name, Id: seal.useraccesscreate.omodel.AccessDetail.Depot.Id };
                                seal.useraccesscreate.omodel.AccessDetails.push(item);
                                seal.useraccesscreate.omodel.cpyAccessDetails.push(item);
                            }

                        });
                    }
                    else {
                        seal.useraccesscreate.omodel.newAccessItemId = seal.useraccesscreate.omodel.newAccessItemId + 1;
                        AccessRights =
                                                   {
                                                       Id: seal.useraccesscreate.omodel.newAccessItemId,
                                                       Module: { Name: seal.useraccesscreate.omodel.AccessDetail.Module.Name, Id: seal.useraccesscreate.omodel.AccessDetail.Module.Id },
                                                       Depot: { Name: seal.useraccesscreate.omodel.AccessDetail.Depot.Name, Id: seal.useraccesscreate.omodel.AccessDetail.Depot.Id },
                                                       Menu: { Id: seal.useraccesscreate.omodel.AccessDetail.Menu.Id, Name: seal.useraccesscreate.omodel.AccessDetail.Menu.Name },
                                                       Features: [],
                                                       RecordRowStatus: seal.common.recordRowStatus.Added,
                                                   };

                        AccessRights.Features = datalist;
                        seal.useraccesscreate.omodel.AccessDetails.push(AccessRights);
                        seal.useraccesscreate.omodel.cpyAccessDetails.push(AccessRights);
                    }
                    seal.useraccesscreate.clearAccessDetailEntry();
                },
                error: function (data) {
                    seal.common.ShowMessage(data.message, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER, [{ text: seal.common.constants.btnOk, action: "seal.useraccesscreate.cancel()" }]);
                }
            });
        }
        else {
            seal.common.ShowMessage(outCome.message, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER);
        }
    },
    confirmcancel: function () {
        seal.common.YesNoShowMessage(seal.common.constants.cancelconfirmation, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER, [{
            text: seal.common.constants.btnYes, action: "seal.useraccesscreate.cancel()"
        }], [{
            text: seal.common.constants.btnNo, action: "seal.common.ClosePopup()"
        }])
    },
    clearDepotDetailsEntry: function () {
        seal.useraccesscreate.omodel.set("IsDepotAddVisible", true);
        seal.useraccesscreate.omodel.set("IsDepotUpdateVisible", false);
        seal.useraccesscreate.omodel.set("IsVisibleDepotGrid", true);
        seal.useraccesscreate.omodel.set("IsVisibleDepotEntry", false);
        seal.useraccesscreate.clearDepot();
    },
    clearAccessDetailEntry: function () {
        seal.useraccesscreate.omodel.set("IsAccessRightsAddVisible", true);
        seal.useraccesscreate.omodel.set("IsAccessRightsUpdateVisible", false);
        seal.useraccesscreate.omodel.set("IsVisibleAccessDetailsGrid", true);
        seal.useraccesscreate.omodel.set("IsVisibleAccessRightsEntry", false);
        seal.useraccesscreate.omodel.set("IsFullModuleAccess", false);
        seal.useraccesscreate.clearAccess();
    },
    clearAccess: function () {
        seal.useraccesscreate.omodel.set("AccessDetail", seal.useraccesscreate.omodel.cpyAccessDetail.toJSON());
        seal.useraccesscreate.omodel.set("CurrentRowAccessIndex", -1);
    },
    clearDepot: function () {
        seal.useraccesscreate.omodel.set("DepotDetail", { Depot: { Name: "", Id: "" }, Region: { Name: "", Id: "" } });
        seal.useraccesscreate.omodel.set("CurrentRowDepotIndex", -1);
    },
    ShowAccessRigths: function (e) {
        var grid = $("#AccessRightsGrid").data("kendoGrid");
        var selectedItem = grid.dataItem($(e.currentTarget).closest("tr"));
        var rowIndex = $(e.currentTarget).closest("tr").index();
        seal.useraccesscreate.omodel.set("SelectedProgrameIndex", rowIndex);
        seal.useraccesscreate.omodel.SelectedProgramId = selectedItem.Menu.Id;
        seal.useraccesscreate.omodel.set("Features", selectedItem.Features);
        $(".featuregrants").trigger('click');
    },
    refreshProp: function (source, desc) {
        source.set("FeatureProgramId", seal.useraccesscreate.omodel.SelectedProgramId);
        source.set("Rights", desc.Rights);
        source.set("IsChanged", true);
        index = seal.useraccesscreate.omodel.SelectedProgrameIndex;
        seal.useraccesscreate.omodel.AccessDetails[index].set("Features", seal.useraccesscreate.omodel.Features);
        seal.useraccesscreate.omodel.AccessDetails[index].RecordRowStatus = seal.common.recordRowStatus.Modified;
    },
    RightsChange: function () {
        index = seal.useraccesscreate.omodel.CurrentFeaturIndex;
        seal.useraccesscreate.omodel.refreshProp(seal.useraccesscreate.omodel.Features[index], seal.useraccesscreate.omodel.Feature);
    },
    confirmSave: function () {
        if (seal.useraccesscreate.omodel.Status.Code == seal.common.constants.deletestatus) {
            seal.common.YesNoShowMessage(seal.common.constants.saveconfirmation, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER,
                [{
                    text: seal.common.constants.btnactivate, action: "seal.useraccesscreate.save()"
                }], [{
                    text: seal.common.constants.btnCancel, action: "seal.common.ClosePopup()"
                }])
        }
        else {
            seal.useraccesscreate.save();
        }
    },
    save: function (e) {
        var outCome = {};
        if (seal.useraccesscreate.omodel.Id == 0) {
            seal.useraccesscreate.omodel.RecordStatus = seal.common.recordRowStatus.Added;
        }
        else {
            seal.useraccesscreate.omodel.RecordStatus = seal.common.recordRowStatus.Modified;
        }
        outCome = seal.validation.IsValid('EditUserDetail');
        if (seal.useraccesscreate.omodel.UsageType != null && seal.useraccesscreate.omodel.UsageType.Code == "D") {
            if (seal.useraccesscreate.omodel.DepotDetails.length == 0) {
                outCome.message += seal.useraccesscreate.messages.MSG_DEPOTMANDATORY;
                outCome.isValid = false;
            }
        }
        if (seal.useraccesscreate.omodel.IsVisibleDepotEntry) {
            outCome.message += seal.useraccesscreate.messages.MSG_ADDDEPOTVALIDATION;
            outCome.isValid = false;
        }
        if (seal.useraccesscreate.omodel.IsVisibleAccessRightsEntry) {
            outCome.message += seal.useraccesscreate.messages.MSG_ADDACCESSVALIDATION;
            outCome.isValid = false;
        }
        if (seal.useraccesscreate.omodel.Id == 0) {
            if (seal.useraccesscreate.omodel.ConfirmPassword != seal.useraccesscreate.omodel.Password) {
                outCome.message += seal.useraccesscreate.messages.MSG_INVALIDPASSWORD;
                outCome.isValid = false;
            }
        }
        if (outCome.isValid) {
            var dmodel = JSON.parse(JSON.stringify(seal.useraccesscreate.omodel));
            dmodel.Status.Code = "A";
            dmodel.Status.Description = "Active";
            Ajax.Request({
                url: seal.useraccesscreate.url.save,
                type: "POST",
                data: dmodel,
                cache: false,
                success: function (data) {
                    if (data.success) {
                        seal.common.ShowMessage(data.message, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER, [{ text: seal.common.constants.btnOk, action: "seal.useraccesscreate.cancel()" }]);
                    }
                    else {
                        seal.common.ShowMessage(data.message, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER, [{
                            text: seal.common.constants.btnOk, action: "seal.common.ClosePopup()"
                        }])
                    }
                },
                error: function (data) {
                    seal.common.ShowMessage(data.message, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER, [{ text: seal.common.constants.btnOk, action: "seal.common.ClosePopup()" }]);
                }
            });
        }
        else {

            seal.common.ShowMessage(outCome.message, seal.useraccesscreate.messages.LBL_UAMMESSAGEHEADER);
        }
    },
    checkDepotAvailable: function () {
        isValid = true;
        if (seal.useraccesscreate.omodel.DepotDetails.length == 0) {
            return false;
        }
        $.each(seal.useraccesscreate.omodel.DepotDetails, function (index, item) {
            if (item.RecordRowStatus == seal.common.recordRowStatus.Added) {

            }
        });
    },
    getLockKey: function () {
        return 'UserAccessManagement_' + seal.useraccesscreate.omodel.Id;
    },
    cancel: function () {
        var key = "";
        var contentContainer = {};
        var searchContainer = {};
        var id = parseInt(seal.useraccesscreate.omodel.Id);
        if (id > 0) {
            key = seal.useraccesscreate.getLockKey();
            StateManager.ReleaseRecord(key, function () {
                contentContainer = document.getElementById('contentarea');
                searchContainer = document.getElementById('searcharea');
                if (searchContainer.innerHTML !== "") {
                    contentContainer.innerHTML = "";
                    contentContainer.appendChild(document.getElementById('UserAccessDiv'));
                    seal.useraccessmangementlist.ApplyFilter();
                }
                else {
                    seal.loader.navigate(seal.useraccesscreate.url.cancel);
                }
            }, []);
        }
        else {
            seal.loader.navigate(seal.useraccesscreate.url.cancel);
        }
        seal.common.close();
    },
    bindModel: function () {
        seal.bind(this.page, this.omodel);
    },


    loadDepotValidation: function () {
        var VH = seal.validation;
        var category = seal.validation.Category.Add('EditDepotDetail', 'divCreatedepotdetail', 'DSA00010', 1);
        VH.Load({ category: 'EditDepotDetail' });
    },
    loadGrantValidation: function () {
        var VH = seal.validation;
        var category = seal.validation.Category.Add('EditGrantDetail', 'divCreategrantdetail', 'DSA00010', 2);
        VH.Load({ category: 'EditGrantDetail' });
    },
};